//! Suffer Distort Blur: blurs each pixel along the direction of the lens gradient,
//! so the smear follows the shapes of the lens. Random jitter hides banding.
//!
//! Speed: when the smear is long, the blur is computed on a reduced copy of the image
//! and blended back over the sharp original wherever the smear is strong.
use suffer_common::lens::{self, LensParams};
use suffer_common::{export_effect, img, noise, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.distort_blur",
  "name": "Suffer Distort Blur",
  "category": "Suffer",
  "params": [
    { "id": "amount",       "name": "Amount",         "type": "slider", "default": 25.0, "min": 0.0, "max": 500.0 },
    { "id": "lens_mode",    "name": "Lens Mode",      "type": "slider", "default": 0.0,  "min": 0.0, "max": 2.0 },
    { "id": "lens_size",    "name": "Lens Size",      "type": "slider", "default": 120.0,"min": 1.0, "max": 1000.0 },
    { "id": "lens_soft",    "name": "Lens Softness",  "type": "slider", "default": 6.0,  "min": 0.0, "max": 100.0 },
    { "id": "lens_speed",   "name": "Lens Speed",     "type": "slider", "default": 0.2,  "min": 0.0, "max": 5.0 },
    { "id": "seed",         "name": "Random Seed",    "type": "slider", "default": 0.0,  "min": 0.0, "max": 100.0 },
    { "id": "samples",      "name": "Samples",        "type": "slider", "default": 8.0,  "min": 3.0, "max": 24.0 }
  ]
}"#;

pub struct Params {
    pub amount: f32,
    pub lens: LensParams,
    pub samples: usize,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            amount: pget(v, 0, 25.0).clamp(0.0, 5000.0),
            lens: LensParams::from_slice(v, 1),
            samples: (pget(v, 6, 8.0).round() as i64).clamp(3, 24) as usize,
        }
    }
}

/// Average `n` samples along (vx, vy) centred on (x, y).
#[inline(always)]
fn smear_at(src: &[f32], w: usize, h: usize, x: f32, y: f32, vx: f32, vy: f32, n: usize, jitter: f32) -> [f32; 4] {
    let inv_n = 1.0 / n as f32;
    let mut acc = [0.0f32; 4];
    for k in 0..n {
        let u = (k as f32 + 0.5 + jitter) * inv_n * 2.0 - 1.0;
        let s = img::bilerp4(src, w, h, x + vx * u, y + vy * u, true);
        acc[0] += s[0];
        acc[1] += s[1];
        acc[2] += s[2];
        acc[3] += s[3];
    }
    [acc[0] * inv_n, acc[1] * inv_n, acc[2] * inv_n, acc[3] * inv_n]
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.amount <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let n4 = w * h * 4;
    let f = lens::gradient(&px[..n4], w, h, time as f32, scale, &p.lens);
    let orig = px[..n4].to_vec();
    let amt = p.amount * scale;
    let ns = p.samples;
    let div = img::pow2_div(amt / 4.0, 8);

    if div == 1 {
        for y in 0..h {
            for x in 0..w {
                let (gx, gy) = f.at(x as f32, y as f32);
                let (vx, vy) = (gx * amt, gy * amt);
                if vx.abs() + vy.abs() < 0.05 {
                    continue; // no slope here: leave the pixel as it is
                }
                let jitter = noise::unit(noise::hash2(x as u32, y as u32, 0xB10C)) - 0.5;
                let c = smear_at(&orig, w, h, x as f32, y as f32, vx, vy, ns, jitter);
                let o = (y * w + x) * 4;
                px[o] = c[0];
                px[o + 1] = c[1];
                px[o + 2] = c[2];
                px[o + 3] = c[3];
            }
        }
        return;
    }

    // Reduced path: blur a smaller copy, then blend it back where the smear is strong.
    let df = div as f32;
    let (small, sw, sh) = img::reduce(&orig, w, h, 4, div);
    let mut blurred = vec![0.0f32; sw * sh * 4];
    for ys in 0..sh {
        let yf = (ys as f32 + 0.5) * df - 0.5;
        for xs in 0..sw {
            let xf = (xs as f32 + 0.5) * df - 0.5;
            let (gx, gy) = f.at(xf, yf);
            let (vx, vy) = (gx * amt / df, gy * amt / df);
            let jitter = noise::unit(noise::hash2(xs as u32, ys as u32, 0xB10C)) - 0.5;
            let c = smear_at(&small, sw, sh, xs as f32, ys as f32, vx, vy, ns, jitter);
            let o = (ys * sw + xs) * 4;
            blurred[o] = c[0];
            blurred[o + 1] = c[1];
            blurred[o + 2] = c[2];
            blurred[o + 3] = c[3];
        }
    }
    let inv_div = 1.0 / df;
    for y in 0..h {
        let sy = (y as f32 + 0.5) * inv_div - 0.5;
        for x in 0..w {
            let (gx, gy) = f.at(x as f32, y as f32);
            let mag = (gx.abs() + gy.abs()) * amt;
            if mag < 0.5 {
                continue;
            }
            let wgt = ((mag - 0.5) / 1.5).min(1.0);
            let sx = (x as f32 + 0.5) * inv_div - 0.5;
            let up = img::bilerp4(&blurred, sw, sh, sx, sy, true);
            let o = (y * w + x) * 4;
            for c in 0..4 {
                px[o + c] = orig[o + c] + (up[c] - orig[o + c]) * wgt;
            }
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke_all_lens_modes_and_both_paths() {
        for mode in 0..3 {
            for amount in [6.0, 40.0] {
                let (w, h) = (48, 40);
                let mut px = suffer_common::test_image(w, h);
                render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[amount, mode as f64]));
                assert!(px.iter().all(|v| v.is_finite()));
            }
        }
    }
}
