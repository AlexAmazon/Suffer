//! Suffer Distort Chroma: only the colour information (not the brightness) is pushed along
//! the lens gradient, in opposite directions for the two colour axes. Edges stay sharp
//! while colour fringes appear around them, like looking through a prism.
use suffer_common::lens::{self, LensParams};
use suffer_common::{color, export_effect, img, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.distort_chroma",
  "name": "Suffer Distort Chroma",
  "category": "Suffer",
  "params": [
    { "id": "amount",       "name": "Amount",         "type": "slider", "default": 12.0, "min": 0.0, "max": 500.0 },
    { "id": "lens_mode",    "name": "Lens Mode",      "type": "slider", "default": 0.0,  "min": 0.0, "max": 2.0 },
    { "id": "lens_size",    "name": "Lens Size",      "type": "slider", "default": 120.0,"min": 1.0, "max": 1000.0 },
    { "id": "lens_soft",    "name": "Lens Softness",  "type": "slider", "default": 6.0,  "min": 0.0, "max": 100.0 },
    { "id": "lens_speed",   "name": "Lens Speed",     "type": "slider", "default": 0.2,  "min": 0.0, "max": 5.0 },
    { "id": "seed",         "name": "Random Seed",    "type": "slider", "default": 0.0,  "min": 0.0, "max": 100.0 }
  ]
}"#;

pub struct Params {
    pub amount: f32,
    pub lens: LensParams,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            amount: pget(v, 0, 12.0).clamp(0.0, 5000.0),
            lens: LensParams::from_slice(v, 1),
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.amount <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let n = w * h;
    let f = lens::gradient(&px[..n * 4], w, h, time as f32, scale, &p.lens);
    let amt = p.amount * scale;

    // Split into brightness (Y) and two colour planes (I, Q).
    let mut yp = vec![0.0f32; n];
    let mut ip = vec![0.0f32; n];
    let mut qp = vec![0.0f32; n];
    for i in 0..n {
        let o = i * 4;
        let a = px[o + 3];
        let (r, g, b) = if a > 1e-4 {
            let inv = 1.0 / a;
            (px[o] * inv, px[o + 1] * inv, px[o + 2] * inv)
        } else {
            (0.0, 0.0, 0.0)
        };
        let (yv, iv, qv) = color::rgb_to_yiq(r, g, b);
        yp[i] = yv;
        ip[i] = iv;
        qp[i] = qv;
    }

    for y in 0..h {
        for x in 0..w {
            let i = y * w + x;
            let (xf, yf) = (x as f32, y as f32);
            let (gx, gy) = f.at(xf, yf);
            let (ax, ay) = (gx * amt, gy * amt);
            let iv = img::bilerp1(&ip, w, h, xf + ax, yf + ay);
            let qv = img::bilerp1(&qp, w, h, xf - ax, yf - ay);
            let (r, g, b) = color::yiq_to_rgb(yp[i], iv, qv);
            let o = i * 4;
            let a = px[o + 3];
            let (r, g, b) = (r.max(0.0) * a, g.max(0.0) * a, b.max(0.0) * a);
            if r.is_finite() && g.is_finite() && b.is_finite() {
                px[o] = r;
                px[o + 1] = g;
                px[o + 2] = b;
            }
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke_all_lens_modes() {
        for mode in 0..3 {
            let (w, h) = (48, 40);
            let mut px = suffer_common::test_image(w, h);
            render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[10.0, mode as f64]));
            assert!(px.iter().all(|v| v.is_finite()));
        }
    }
}
