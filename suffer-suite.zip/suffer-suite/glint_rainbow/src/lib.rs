//! Suffer Glint Rainbow: star-shaped rainbow glints on bright spots.
//! The drawing is done by the shared engine in suffer_common::glint (reduced-resolution
//! rays, capped emitter count), which is also used by Suffer Glint.
use suffer_common::glint::{self, GlintCfg};
use suffer_common::{export_effect, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.glint_rainbow",
  "name": "Suffer Glint Rainbow",
  "category": "Suffer",
  "params": [
    { "id": "threshold",  "name": "Threshold",        "type": "slider", "default": 0.8, "min": 0.0, "max": 4.0 },
    { "id": "brightness", "name": "Brightness",       "type": "slider", "default": 1.0, "min": 0.0, "max": 10.0 },
    { "id": "size",       "name": "Size",             "type": "slider", "default": 120.0, "min": 0.0, "max": 1000.0 },
    { "id": "shift_out",  "name": "Shift Out",        "type": "slider", "default": 1.0, "min": 0.0, "max": 8.0 },
    { "id": "hue_offset", "name": "Hue Offset",       "type": "slider", "default": 0.0, "min": 0.0, "max": 1.0 },
    { "id": "rays",       "name": "Rays",             "type": "slider", "default": 4.0, "min": 1.0, "max": 16.0 },
    { "id": "angle",      "name": "Angle",            "type": "angle",  "default": 0.0 },
    { "id": "saturation", "name": "Saturation",       "type": "slider", "default": 1.0, "min": 0.0, "max": 1.0 },
    { "id": "color_mix",  "name": "Source Color Mix", "type": "slider", "default": 0.0, "min": 0.0, "max": 1.0 }
  ]
}"#;

pub struct Params {
    pub cfg: GlintCfg,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            cfg: GlintCfg {
                threshold: pget(v, 0, 0.8).max(0.0),
                brightness: pget(v, 1, 1.0).max(0.0),
                size: pget(v, 2, 120.0).clamp(0.0, 4000.0),
                cycles: pget(v, 3, 1.0).max(0.0),
                hue_offset: pget(v, 4, 0.0),
                rays: (pget(v, 5, 4.0).round() as i64).clamp(1, 16) as usize,
                angle: pget(v, 6, 0.0).to_radians(),
                saturation: pget(v, 7, 1.0).clamp(0.0, 1.0),
                color_mix: pget(v, 8, 0.0).clamp(0.0, 1.0),
                rainbow: true,
            },
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, scale: f32, p: &Params) {
    glint::render(px, w, h, scale, &p.cfg);
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn spot_gets_rays_and_stays_finite() {
        let (w, h) = (128, 128);
        let mut px = vec![0.0f32; w * h * 4];
        for i in 0..w * h {
            px[i * 4 + 3] = 1.0;
        }
        let c = ((h / 2) * w + w / 2) * 4;
        px[c] = 4.0;
        px[c + 1] = 4.0;
        px[c + 2] = 4.0;
        render(&mut px, w, h, 0.0, 1.0, &Params::from_slice(&[0.5, 1.0, 40.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0]));
        assert!(px.iter().all(|v| v.is_finite()));
        let near = &px[((h / 2) * w + w / 2 + 12) * 4..][..3];
        assert!(near.iter().any(|&v| v > 0.01), "ray should be lit");
    }
    #[test]
    fn dark_frame_is_a_no_op() {
        let (w, h) = (32, 32);
        let mut px = vec![0.05f32; w * h * 4];
        let before = px.clone();
        render(&mut px, w, h, 0.0, 1.0, &Params::from_slice(&[]));
        assert_eq!(px, before);
    }
}
