//! Suffer Directional Blur: smear along a line.
//! Speed: straight horizontal / vertical blurs use a fast box blur; angled or
//! off-centre blurs run at reduced resolution when they are long. Random jitter
//! hides the banding you would otherwise see with few samples.
use suffer_common::{export_effect, img, noise, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.blur_directional",
  "name": "Suffer Directional Blur",
  "category": "Suffer",
  "params": [
    { "id": "length",  "name": "Length",  "type": "slider", "default": 30.0, "min": 0.0,  "max": 500.0 },
    { "id": "angle",   "name": "Angle",   "type": "angle",  "default": 0.0 },
    { "id": "balance", "name": "Balance", "type": "slider", "default": 0.5,  "min": 0.0,  "max": 1.0 },
    { "id": "samples", "name": "Samples", "type": "slider", "default": 16.0, "min": 4.0,  "max": 48.0 }
  ]
}"#;

pub struct Params {
    pub length: f32,
    pub angle: f32, // radians
    pub balance: f32,
    pub samples: usize,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            length: pget(v, 0, 30.0).clamp(0.0, 2000.0),
            angle: pget(v, 1, 0.0).to_radians(),
            balance: pget(v, 2, 0.5).clamp(0.0, 1.0),
            samples: (pget(v, 3, 16.0).round() as i64).clamp(4, 48) as usize,
        }
    }
}

/// Blur `src` into `out` along (dx, dy) over `len` pixels.
fn smear(src: &[f32], out: &mut [f32], w: usize, h: usize, len: f32, dx: f32, dy: f32, balance: f32, samples: usize) {
    let n = ((len.ceil() as usize).max(3)).min(samples);
    let inv_n = 1.0 / n as f32;
    for y in 0..h {
        for x in 0..w {
            let jitter = noise::unit(noise::hash2(x as u32, y as u32, 0x51ED)) - 0.5;
            let mut acc = [0.0f32; 4];
            for k in 0..n {
                let u = (k as f32 + 0.5 + jitter) * inv_n;
                let t = (u - balance) * len;
                let v = img::bilerp4(src, w, h, x as f32 + dx * t, y as f32 + dy * t, true);
                acc[0] += v[0];
                acc[1] += v[1];
                acc[2] += v[2];
                acc[3] += v[3];
            }
            let o = (y * w + x) * 4;
            out[o] = acc[0] * inv_n;
            out[o + 1] = acc[1] * inv_n;
            out[o + 2] = acc[2] * inv_n;
            out[o + 3] = acc[3] * inv_n;
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, scale: f32, p: &Params) {
    let len = p.length * scale;
    if w < 4 || h < 4 || len < 0.5 || px.len() < w * h * 4 {
        return;
    }
    let n = w * h * 4;
    let (dy, dx) = p.angle.sin_cos();

    // Fast path: straight and centred = a plain box blur.
    if (p.balance - 0.5).abs() < 0.01 {
        let r = ((len * 0.5).round() as usize).max(1);
        if dy.abs() < 1e-3 {
            img::box_blur(&mut px[..n], w, h, 4, r, 0);
            return;
        }
        if dx.abs() < 1e-3 {
            img::box_blur(&mut px[..n], w, h, 4, 0, r);
            return;
        }
    }

    let div = img::pow2_div(len / 20.0, 8);
    if div == 1 {
        let orig = px[..n].to_vec();
        smear(&orig, &mut px[..n], w, h, len, dx, dy, p.balance, p.samples);
    } else {
        let (small, sw, sh) = img::reduce(&px[..n], w, h, 4, div);
        let mut out = vec![0.0f32; sw * sh * 4];
        smear(&small, &mut out, sw, sh, len / div as f32, dx, dy, p.balance, p.samples);
        let up = img::upsample4(&out, sw, sh, w, h);
        px[..n].copy_from_slice(&up);
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (64, 48);
        // straight, angled, off-centre and long
        for params in [[30.0, 0.0, 0.5], [30.0, 40.0, 0.5], [30.0, 0.0, 0.2], [120.0, 33.0, 0.5]] {
            let mut px = suffer_common::test_image(w, h);
            render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&params));
            assert!(px.iter().all(|v| v.is_finite()));
        }
    }
}
