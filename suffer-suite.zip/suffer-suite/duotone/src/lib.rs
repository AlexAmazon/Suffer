//! Suffer Duotone: maps brightness onto a gradient between a shadow colour and a
//! highlight colour. Colours are picked by hue and saturation.
use suffer_common::{color, export_effect, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.duotone",
  "name": "Suffer Duotone",
  "category": "Suffer",
  "params": [
    { "id": "shadow_hue",   "name": "Shadow Hue",         "type": "slider", "default": 0.62, "min": 0.0, "max": 1.0 },
    { "id": "shadow_sat",   "name": "Shadow Saturation",  "type": "slider", "default": 0.8,  "min": 0.0, "max": 1.0 },
    { "id": "highlight_hue","name": "Highlight Hue",      "type": "slider", "default": 0.09, "min": 0.0, "max": 1.0 },
    { "id": "highlight_sat","name": "Highlight Saturation","type": "slider", "default": 0.7, "min": 0.0, "max": 1.0 },
    { "id": "contrast",     "name": "Contrast",           "type": "slider", "default": 1.0,  "min": 0.0, "max": 4.0 },
    { "id": "balance",      "name": "Balance",            "type": "slider", "default": 0.5,  "min": 0.0, "max": 1.0 },
    { "id": "mix",          "name": "Mix",                "type": "slider", "default": 1.0,  "min": 0.0, "max": 1.0 }
  ]
}"#;

pub struct Params {
    pub shadow_hue: f32,
    pub shadow_sat: f32,
    pub highlight_hue: f32,
    pub highlight_sat: f32,
    pub contrast: f32,
    pub balance: f32,
    pub mix: f32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            shadow_hue: pget(v, 0, 0.62),
            shadow_sat: pget(v, 1, 0.8).clamp(0.0, 1.0),
            highlight_hue: pget(v, 2, 0.09),
            highlight_sat: pget(v, 3, 0.7).clamp(0.0, 1.0),
            contrast: pget(v, 4, 1.0).clamp(0.0, 8.0),
            balance: pget(v, 5, 0.5).clamp(0.0, 1.0),
            mix: pget(v, 6, 1.0).clamp(0.0, 1.0),
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, _scale: f32, p: &Params) {
    if w < 1 || h < 1 || p.mix <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let sh = color::hsv_to_rgb(p.shadow_hue, p.shadow_sat, 0.12);
    let hi = color::hsv_to_rgb(p.highlight_hue, p.highlight_sat, 1.0);
    for i in 0..w * h {
        let o = i * 4;
        let a = px[o + 3];
        if a <= 1e-4 {
            continue;
        }
        let inv = 1.0 / a;
        let l = color::luma(px[o] * inv, px[o + 1] * inv, px[o + 2] * inv);
        if !l.is_finite() {
            continue;
        }
        let t = ((l - p.balance) * p.contrast + 0.5).clamp(0.0, 1.0);
        for c in 0..3 {
            let target = (sh[c] + (hi[c] - sh[c]) * t) * a;
            px[o + c] += (target - px[o + c]) * p.mix;
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (48, 40);
        let mut px = suffer_common::test_image(w, h);
        let before = px.clone();
        render(&mut px, w, h, 0.0, 1.0, &Params::from_slice(&[]));
        assert!(px.iter().all(|v| v.is_finite()));
        assert_ne!(px, before);
    }
}
