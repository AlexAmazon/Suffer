//! Suffer Glow: bright-pass, a pyramid of blurs from fine to wide, added back on.
//! Speed: the bright-pass and the first halving happen in one pass, frames with no
//! highlights return immediately, the pyramid uses tiny 3-pixel blurs (bilinear
//! upsampling smooths the rest) and the last upsample is fused with the add.
use suffer_common::{color, export_effect, img, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.glow",
  "name": "Suffer Glow",
  "category": "Suffer",
  "params": [
    { "id": "threshold",   "name": "Threshold",   "type": "slider", "default": 0.6,  "min": 0.0, "max": 4.0 },
    { "id": "softness",    "name": "Softness",    "type": "slider", "default": 0.4,  "min": 0.0, "max": 2.0 },
    { "id": "size",        "name": "Size",        "type": "slider", "default": 60.0, "min": 0.0, "max": 500.0 },
    { "id": "brightness",  "name": "Brightness",  "type": "slider", "default": 1.0,  "min": 0.0, "max": 10.0 },
    { "id": "falloff",     "name": "Falloff",     "type": "slider", "default": 0.7,  "min": 0.0, "max": 3.0 },
    { "id": "tint_amount", "name": "Tint Amount", "type": "slider", "default": 0.0,  "min": 0.0, "max": 1.0 },
    { "id": "tint_hue",    "name": "Tint Hue",    "type": "slider", "default": 0.08, "min": 0.0, "max": 1.0 },
    { "id": "source_mix",  "name": "Source Mix",  "type": "slider", "default": 1.0,  "min": 0.0, "max": 1.0 }
  ]
}"#;

pub struct Params {
    pub threshold: f32,
    pub softness: f32,
    pub size: f32,
    pub brightness: f32,
    pub falloff: f32,
    pub tint_amount: f32,
    pub tint_hue: f32,
    pub source_mix: f32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            threshold: pget(v, 0, 0.6).max(0.0),
            softness: pget(v, 1, 0.4).max(0.0),
            size: pget(v, 2, 60.0).clamp(0.0, 2000.0),
            brightness: pget(v, 3, 1.0).max(0.0),
            falloff: pget(v, 4, 0.7).clamp(0.0, 10.0),
            tint_amount: pget(v, 5, 0.0).clamp(0.0, 1.0),
            tint_hue: pget(v, 6, 0.08),
            source_mix: pget(v, 7, 1.0).clamp(0.0, 1.0),
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.brightness <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let size = p.size * scale;
    if size < 1.0 {
        return;
    }
    let n = w * h;

    // 1. Bright pass fused with the first halving. Nothing bright = nothing to do.
    let knee = p.softness * 0.5;
    let (first, w1, h1, any) = img::bright_reduce(&px[..n * 4], w, h, p.threshold, knee, 2);
    if !any {
        if p.source_mix < 1.0 {
            for i in 0..n {
                let o = i * 4;
                px[o] *= p.source_mix;
                px[o + 1] *= p.source_mix;
                px[o + 2] *= p.source_mix;
                px[o + 3] *= p.source_mix;
            }
        }
        return;
    }

    // 2. Pyramid: level 0 is half size, each next level halves again. Light 3x3 blur on each.
    let levels_n = (size.log2().ceil().max(1.0) as usize).min(8);
    let mut levels: Vec<(Vec<f32>, usize, usize)> = Vec::with_capacity(levels_n);
    let mut cur = first;
    let mut cw = w1;
    let mut ch = h1;
    for i in 0..levels_n {
        if i > 0 {
            let (d, dw, dh) = img::downsample2(&cur, cw, ch, 4);
            cur = d;
            cw = dw;
            ch = dh;
        }
        img::box_blur(&mut cur, cw, ch, 4, 1, 1);
        levels.push((cur.clone(), cw, ch));
    }

    // 3. Weights: wide levels count less as Falloff rises. They sum to 1.
    let mut wts: Vec<f32> = (0..levels_n).map(|i| 1.0 / (1.0 + i as f32 * p.falloff)).collect();
    let sum: f32 = wts.iter().sum();
    for wt in wts.iter_mut() {
        *wt /= sum;
    }

    // 4. Rebuild from the widest level down, upsampling as we go.
    let last = levels_n - 1;
    let mut acc: Vec<f32> = levels[last].0.iter().map(|v| v * wts[last]).collect();
    let mut aw = levels[last].1;
    let mut ah = levels[last].2;
    for i in (0..last).rev() {
        let lvl = &levels[i];
        let mut up = img::upsample4(&acc, aw, ah, lvl.1, lvl.2);
        for (u, v) in up.iter_mut().zip(lvl.0.iter()) {
            *u += *v * wts[i];
        }
        acc = up;
        aw = lvl.1;
        ah = lvl.2;
    }

    // 5. Fused last upsample + tint + add. Alpha rises under bright glow so it survives on transparency.
    let tc = color::hsv_to_rgb(p.tint_hue, 1.0, 1.0);
    let m0 = p.brightness * (1.0 + p.tint_amount * (tc[0] - 1.0));
    let m1 = p.brightness * (1.0 + p.tint_amount * (tc[1] - 1.0));
    let m2 = p.brightness * (1.0 + p.tint_amount * (tc[2] - 1.0));
    let rx = aw as f32 / w as f32;
    let ry = ah as f32 / h as f32;
    let smix = p.source_mix;
    for y in 0..h {
        let sy = (y as f32 + 0.5) * ry - 0.5;
        let mut sx = 0.5 * rx - 0.5;
        for x in 0..w {
            let g = img::bilerp4(&acc, aw, ah, sx, sy, true);
            sx += rx;
            let o = (y * w + x) * 4;
            let gr = g[0] * m0;
            let gg = g[1] * m1;
            let gb = g[2] * m2;
            let r = px[o] * smix + gr;
            let gn = px[o + 1] * smix + gg;
            let b = px[o + 2] * smix + gb;
            let cover = gr.max(gg).max(gb).min(1.0);
            let a = (px[o + 3] * smix).max(cover);
            if r.is_finite() && gn.is_finite() && b.is_finite() && a.is_finite() {
                px[o] = r;
                px[o + 1] = gn;
                px[o + 2] = b;
                px[o + 3] = a;
            }
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (64, 48);
        let mut px = suffer_common::test_image(w, h);
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[]));
        assert!(px.iter().all(|v| v.is_finite()));
    }
    #[test]
    fn nothing_bright_is_a_no_op() {
        let (w, h) = (32, 24);
        let mut px = vec![0.1f32; w * h * 4];
        let before = px.clone();
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[]));
        assert_eq!(px, before);
    }
}
