//! Suffer Glint: star-shaped glints on bright spots, in the colour of the source
//! (or white). Uses the same engine as Glint Rainbow, minus the rainbow.
use suffer_common::glint::{self, GlintCfg};
use suffer_common::{export_effect, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.glint",
  "name": "Suffer Glint",
  "category": "Suffer",
  "params": [
    { "id": "threshold",  "name": "Threshold",  "type": "slider", "default": 0.8,   "min": 0.0, "max": 4.0 },
    { "id": "brightness", "name": "Brightness", "type": "slider", "default": 1.0,   "min": 0.0, "max": 10.0 },
    { "id": "size",       "name": "Size",       "type": "slider", "default": 120.0, "min": 0.0, "max": 1000.0 },
    { "id": "rays",       "name": "Rays",       "type": "slider", "default": 4.0,   "min": 1.0, "max": 16.0 },
    { "id": "angle",      "name": "Angle",      "type": "angle",  "default": 0.0 },
    { "id": "white_mix",  "name": "White Mix",  "type": "slider", "default": 0.0,   "min": 0.0, "max": 1.0 }
  ]
}"#;

pub struct Params {
    pub cfg: GlintCfg,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            cfg: GlintCfg {
                threshold: pget(v, 0, 0.8).max(0.0),
                brightness: pget(v, 1, 1.0).max(0.0),
                size: pget(v, 2, 120.0).clamp(0.0, 4000.0),
                cycles: 0.0,
                hue_offset: 0.0,
                rays: (pget(v, 3, 4.0).round() as i64).clamp(1, 16) as usize,
                angle: pget(v, 4, 0.0).to_radians(),
                saturation: 0.0,
                color_mix: 1.0 - pget(v, 5, 0.0).clamp(0.0, 1.0),
                rainbow: false,
            },
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, scale: f32, p: &Params) {
    glint::render(px, w, h, scale, &p.cfg);
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (64, 48);
        let mut px = suffer_common::test_image(w, h);
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[0.5]));
        assert!(px.iter().all(|v| v.is_finite()));
    }
}
