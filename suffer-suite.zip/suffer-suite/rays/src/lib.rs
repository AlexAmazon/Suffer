//! Suffer Rays: light rays streaming outward from a point. Bright areas are
//! smeared away from the centre. Done at reduced resolution (rays are soft).
use suffer_common::{export_effect, img, noise, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.rays",
  "name": "Suffer Rays",
  "category": "Suffer",
  "params": [
    { "id": "threshold",  "name": "Threshold",  "type": "slider", "default": 0.6, "min": 0.0, "max": 4.0 },
    { "id": "softness",   "name": "Softness",   "type": "slider", "default": 0.3, "min": 0.0, "max": 2.0 },
    { "id": "brightness", "name": "Brightness", "type": "slider", "default": 1.0, "min": 0.0, "max": 10.0 },
    { "id": "length",     "name": "Length",     "type": "slider", "default": 0.5, "min": 0.0, "max": 1.0 },
    { "id": "center_x",   "name": "Center X",   "type": "slider", "default": 0.5, "min": 0.0, "max": 1.0 },
    { "id": "center_y",   "name": "Center Y",   "type": "slider", "default": 0.5, "min": 0.0, "max": 1.0 },
    { "id": "samples",    "name": "Samples",    "type": "slider", "default": 16.0, "min": 4.0, "max": 48.0 }
  ]
}"#;

pub struct Params {
    pub threshold: f32,
    pub softness: f32,
    pub brightness: f32,
    pub length: f32,
    pub center_x: f32,
    pub center_y: f32,
    pub samples: usize,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            threshold: pget(v, 0, 0.6).max(0.0),
            softness: pget(v, 1, 0.3).max(0.0),
            brightness: pget(v, 2, 1.0).max(0.0),
            length: pget(v, 3, 0.5).clamp(0.0, 1.0),
            center_x: pget(v, 4, 0.5),
            center_y: pget(v, 5, 0.5),
            samples: (pget(v, 6, 16.0).round() as i64).clamp(4, 48) as usize,
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, _scale: f32, p: &Params) {
    if w < 8 || h < 8 || p.brightness <= 0.0 || p.length <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let div = if w >= 600 { 4 } else { 2 };
    let (bright, sw, sh, any) = img::bright_reduce(&px[..w * h * 4], w, h, p.threshold, p.softness * 0.5, div);
    if !any {
        return;
    }
    let divf = div as f32;
    let cxr = p.center_x * w as f32 / divf - 0.5;
    let cyr = p.center_y * h as f32 / divf - 0.5;
    let n = p.samples;
    let inv_n = 1.0 / n as f32;

    // Every pixel looks toward the centre and gathers brightness from the points on the way.
    let mut rays = vec![0.0f32; sw * sh * 4];
    for y in 0..sh {
        for x in 0..sw {
            let dx = cxr - x as f32;
            let dy = cyr - y as f32;
            let jitter = noise::unit(noise::hash2(x as u32, y as u32, 0x7A)) - 0.5;
            let mut acc = [0.0f32; 3];
            for k in 0..n {
                let u = (k as f32 + 0.5 + jitter) * inv_n;
                let wgt = (1.0 - u) * (1.0 - u);
                let s = u * p.length;
                let v = img::bilerp4(&bright, sw, sh, x as f32 + dx * s, y as f32 + dy * s, true);
                acc[0] += v[0] * wgt;
                acc[1] += v[1] * wgt;
                acc[2] += v[2] * wgt;
            }
            let o = (y * sw + x) * 4;
            rays[o] = acc[0] * inv_n;
            rays[o + 1] = acc[1] * inv_n;
            rays[o + 2] = acc[2] * inv_n;
        }
    }

    // Expand and add. Alpha rises under the rays so they survive on transparency.
    let inv_div = 1.0 / divf;
    for y in 0..h {
        let sy = (y as f32 + 0.5) * inv_div - 0.5;
        for x in 0..w {
            let sx = (x as f32 + 0.5) * inv_div - 0.5;
            let g = img::bilerp4(&rays, sw, sh, sx, sy, true);
            let (gr, gg, gb) = (g[0] * p.brightness, g[1] * p.brightness, g[2] * p.brightness);
            if gr == 0.0 && gg == 0.0 && gb == 0.0 {
                continue;
            }
            let o = (y * w + x) * 4;
            let (r, gn, b) = (px[o] + gr, px[o + 1] + gg, px[o + 2] + gb);
            if r.is_finite() && gn.is_finite() && b.is_finite() {
                px[o] = r;
                px[o + 1] = gn;
                px[o + 2] = b;
                px[o + 3] = px[o + 3].max(gr.max(gg).max(gb).min(1.0));
            }
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (96, 64);
        let mut px = suffer_common::test_image(w, h);
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[0.5]));
        assert!(px.iter().all(|v| v.is_finite()));
    }
}
