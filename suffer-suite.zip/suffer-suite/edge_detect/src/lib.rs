//! Suffer Edge Detect: Sobel edges on brightness. Edges can be white or take the
//! source colour, and can be drawn alone or over the original.
use suffer_common::{export_effect, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.edge_detect",
  "name": "Suffer Edge Detect",
  "category": "Suffer",
  "params": [
    { "id": "strength",      "name": "Strength",       "type": "slider", "default": 1.0,  "min": 0.0, "max": 10.0 },
    { "id": "threshold",     "name": "Threshold",      "type": "slider", "default": 0.05, "min": 0.0, "max": 1.0 },
    { "id": "softness",      "name": "Softness",       "type": "slider", "default": 0.2,  "min": 0.0, "max": 1.0 },
    { "id": "original_mix",  "name": "Original Mix",   "type": "slider", "default": 0.0,  "min": 0.0, "max": 1.0 },
    { "id": "color_amount",  "name": "Source Color",   "type": "slider", "default": 0.0,  "min": 0.0, "max": 1.0 },
    { "id": "invert",        "name": "Invert (0 or 1)","type": "slider", "default": 0.0,  "min": 0.0, "max": 1.0 }
  ]
}"#;

pub struct Params {
    pub strength: f32,
    pub threshold: f32,
    pub softness: f32,
    pub original_mix: f32,
    pub color_amount: f32,
    pub invert: bool,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            strength: pget(v, 0, 1.0).clamp(0.0, 50.0),
            threshold: pget(v, 1, 0.05).clamp(0.0, 4.0),
            softness: pget(v, 2, 0.2).clamp(0.0, 4.0),
            original_mix: pget(v, 3, 0.0).clamp(0.0, 1.0),
            color_amount: pget(v, 4, 0.0).clamp(0.0, 1.0),
            invert: pget(v, 5, 0.0) > 0.5,
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, _scale: f32, p: &Params) {
    if w < 3 || h < 3 || px.len() < w * h * 4 {
        return;
    }
    let n = w * h;

    // Brightness plane.
    let mut l = vec![0.0f32; n];
    for i in 0..n {
        let o = i * 4;
        let v = 0.2126 * px[o] + 0.7152 * px[o + 1] + 0.0722 * px[o + 2];
        l[i] = if v.is_finite() { v.clamp(0.0, 4.0) } else { 0.0 };
    }

    let soft = p.softness.max(1e-4);
    for y in 0..h {
        let ym = y.saturating_sub(1) * w;
        let yc = y * w;
        let yp = (y + 1).min(h - 1) * w;
        for x in 0..w {
            let xm = x.saturating_sub(1);
            let xp = (x + 1).min(w - 1);
            let gx = (l[ym + xp] + 2.0 * l[yc + xp] + l[yp + xp]) - (l[ym + xm] + 2.0 * l[yc + xm] + l[yp + xm]);
            let gy = (l[yp + xm] + 2.0 * l[yp + x] + l[yp + xp]) - (l[ym + xm] + 2.0 * l[ym + x] + l[ym + xp]);
            let mag = (gx * gx + gy * gy).sqrt() * p.strength * 0.25;
            let t = ((mag - p.threshold) / soft).clamp(0.0, 1.0);
            let mut e = t * t * (3.0 - 2.0 * t);
            if p.invert {
                e = 1.0 - e;
            }

            let o = (y * w + x) * 4;
            let a = px[o + 3];
            // Edge colour: white, or the source colour scaled so its brightest channel is 1.
            let (mut er, mut eg, mut eb) = (1.0f32, 1.0f32, 1.0f32);
            if p.color_amount > 0.0 && a > 1e-4 {
                let inv = 1.0 / a;
                let (r, g, b) = (px[o] * inv, px[o + 1] * inv, px[o + 2] * inv);
                let m = r.max(g).max(b).max(1e-4);
                er = 1.0 + p.color_amount * (r / m - 1.0);
                eg = 1.0 + p.color_amount * (g / m - 1.0);
                eb = 1.0 + p.color_amount * (b / m - 1.0);
            }
            let om = p.original_mix;
            let r = px[o] * om + er * e * a;
            let g = px[o + 1] * om + eg * e * a;
            let b = px[o + 2] * om + eb * e * a;
            if r.is_finite() && g.is_finite() && b.is_finite() {
                px[o] = r;
                px[o + 1] = g;
                px[o + 2] = b;
            }
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke_all_options() {
        let (w, h) = (48, 40);
        for opts in [[1.0, 0.05, 0.2, 0.0, 0.0, 0.0], [3.0, 0.0, 0.1, 0.5, 1.0, 1.0]] {
            let mut px = suffer_common::test_image(w, h);
            render(&mut px, w, h, 0.0, 1.0, &Params::from_slice(&opts));
            assert!(px.iter().all(|v| v.is_finite()));
        }
    }
}
