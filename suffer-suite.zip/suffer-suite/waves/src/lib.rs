//! Suffer Waves: travelling sine waves that ripple the image sideways.
//! Speed: the wave phase is rotated step by step along each row instead of calling
//! sin() for every pixel.
use suffer_common::{export_effect, img, pget, PI};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.waves",
  "name": "Suffer Waves",
  "category": "Suffer",
  "params": [
    { "id": "amount",     "name": "Amount",      "type": "slider", "default": 20.0,  "min": 0.0, "max": 500.0 },
    { "id": "wavelength", "name": "Wavelength",  "type": "slider", "default": 120.0, "min": 4.0, "max": 2000.0 },
    { "id": "speed",      "name": "Speed",       "type": "slider", "default": 0.5,   "min": 0.0, "max": 10.0 },
    { "id": "angle",      "name": "Angle",       "type": "angle",  "default": 0.0 },
    { "id": "harmonics",  "name": "Sharpness",   "type": "slider", "default": 0.3,   "min": 0.0, "max": 1.0 }
  ]
}"#;

pub struct Params {
    pub amount: f32,
    pub wavelength: f32,
    pub speed: f32,
    pub angle: f32, // radians
    pub harmonics: f32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            amount: pget(v, 0, 20.0).clamp(0.0, 5000.0),
            wavelength: pget(v, 1, 120.0).clamp(4.0, 20000.0),
            speed: pget(v, 2, 0.5).clamp(0.0, 100.0),
            angle: pget(v, 3, 0.0).to_radians(),
            harmonics: pget(v, 4, 0.3).clamp(0.0, 1.0),
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.amount <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let n4 = w * h * 4;
    let orig = px[..n4].to_vec();
    let amt = p.amount * scale;
    let k = 2.0 * PI / (p.wavelength * scale).max(2.0);
    let (sa, ca) = p.angle.sin_cos();
    let omega_t = 2.0 * PI * p.speed * (time as f32);
    // Phase advances by `step` per pixel along x; (sd, cd) is that rotation.
    let step = k * ca;
    let (sd, cd) = step.sin_cos();
    for y in 0..h {
        let (mut s, mut c) = (k * (y as f32) * sa - omega_t).sin_cos();
        for x in 0..w {
            let disp = amt * (s + p.harmonics * s * c);
            // Displace perpendicular to the direction the wave travels.
            let (xf, yf) = (x as f32, y as f32);
            let v = img::bilerp4(&orig, w, h, xf - sa * disp, yf + ca * disp, true);
            let o = (y * w + x) * 4;
            px[o] = v[0];
            px[o + 1] = v[1];
            px[o + 2] = v[2];
            px[o + 3] = v[3];
            let ns = s * cd + c * sd;
            let nc = c * cd - s * sd;
            s = ns;
            c = nc;
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (64, 48);
        let mut px = suffer_common::test_image(w, h);
        let before = px.clone();
        render(&mut px, w, h, 0.7, 1.0, &Params::from_slice(&[]));
        assert!(px.iter().all(|v| v.is_finite()));
        assert_ne!(px, before);
    }
}
