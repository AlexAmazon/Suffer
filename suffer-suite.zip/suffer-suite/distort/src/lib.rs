//! Suffer Distort: warps the image along the gradient of a lens (glass-like refraction).
use suffer_common::lens::{self, LensParams};
use suffer_common::{export_effect, img, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.distort",
  "name": "Suffer Distort",
  "category": "Suffer",
  "params": [
    { "id": "amount",       "name": "Amount",         "type": "slider", "default": 30.0, "min": 0.0, "max": 500.0 },
    { "id": "lens_mode",    "name": "Lens Mode",      "type": "slider", "default": 0.0,  "min": 0.0, "max": 2.0 },
    { "id": "lens_size",    "name": "Lens Size",      "type": "slider", "default": 120.0,"min": 1.0, "max": 1000.0 },
    { "id": "lens_soft",    "name": "Lens Softness",  "type": "slider", "default": 6.0,  "min": 0.0, "max": 100.0 },
    { "id": "lens_speed",   "name": "Lens Speed",     "type": "slider", "default": 0.2,  "min": 0.0, "max": 5.0 },
    { "id": "seed",         "name": "Random Seed",    "type": "slider", "default": 0.0,  "min": 0.0, "max": 100.0 }
  ]
}"#;

pub struct Params {
    pub amount: f32,
    pub lens: LensParams,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            amount: pget(v, 0, 30.0).clamp(0.0, 5000.0),
            lens: LensParams::from_slice(v, 1),
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.amount <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let n4 = w * h * 4;
    let f = lens::gradient(&px[..n4], w, h, time as f32, scale, &p.lens);
    let orig = px[..n4].to_vec();
    let amt = p.amount * scale;
    for y in 0..h {
        for x in 0..w {
            let (gx, gy) = f.at(x as f32, y as f32);
            let c = img::bilerp4(&orig, w, h, x as f32 + gx * amt, y as f32 + gy * amt, true);
            let o = (y * w + x) * 4;
            px[o] = c[0];
            px[o + 1] = c[1];
            px[o + 2] = c[2];
            px[o + 3] = c[3];
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke_all_lens_modes() {
        for mode in 0..3 {
            let (w, h) = (48, 40);
            let mut px = suffer_common::test_image(w, h);
            render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[20.0, mode as f64]));
            assert!(px.iter().all(|v| v.is_finite()));
        }
    }
}
