@echo off
setlocal enabledelayedexpansion
rem Builds every Suffer plug-in separately, so one broken effect does not stop the others.
rem Run from inside this folder:   .\build.bat

rustup target add wasm32-unknown-unknown
if not exist dist mkdir dist
set FAILED=

for %%E in (glint_rainbow vhs_damage shake glow tv_damage distort distort_rgb distort_chroma distort_blur blur blur_directional glint film_damage rays waves vortex edge_detect duotone) do (
    echo.
    echo ===== Building %%E =====
    cargo build --release --target wasm32-unknown-unknown -p suffer_%%E
    if errorlevel 1 (
        set FAILED=!FAILED! %%E
    ) else (
        copy /Y target\wasm32-unknown-unknown\release\suffer_%%E.wasm dist\ >nul
    )
)

echo.
echo ==========================================
if defined FAILED (
    echo These effects FAILED to build:%FAILED%
    echo Copy the red error text above and send it over.
) else (
    echo All plug-ins built successfully.
)
echo.
echo Finished plug-ins in the dist folder:
dir /b dist\*.wasm
