//! Suffer Film Damage: old film stock. Grain, vertical scratches, dust and hairs,
//! exposure flicker and gate weave. Everything is procedural and changes 24 times
//! a second like real film. Cheap per pixel: one hash for grain, the rest is drawn
//! as a handful of small shapes.
use suffer_common::{export_effect, noise, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.film_damage",
  "name": "Suffer Film Damage",
  "category": "Suffer",
  "params": [
    { "id": "amount",    "name": "Amount",    "type": "slider", "default": 1.0, "min": 0.0, "max": 1.0 },
    { "id": "grain",     "name": "Grain",     "type": "slider", "default": 0.3, "min": 0.0, "max": 1.0 },
    { "id": "scratches", "name": "Scratches", "type": "slider", "default": 0.3, "min": 0.0, "max": 1.0 },
    { "id": "dust",      "name": "Dust",      "type": "slider", "default": 0.3, "min": 0.0, "max": 1.0 },
    { "id": "flicker",   "name": "Flicker",   "type": "slider", "default": 0.2, "min": 0.0, "max": 1.0 },
    { "id": "weave",     "name": "Gate Weave","type": "slider", "default": 0.2, "min": 0.0, "max": 1.0 },
    { "id": "seed",      "name": "Random Seed","type": "slider", "default": 0.0, "min": 0.0, "max": 100.0 }
  ]
}"#;

pub struct Params {
    pub amount: f32,
    pub grain: f32,
    pub scratches: f32,
    pub dust: f32,
    pub flicker: f32,
    pub weave: f32,
    pub seed: u32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            amount: pget(v, 0, 1.0).clamp(0.0, 1.0),
            grain: pget(v, 1, 0.3).clamp(0.0, 1.0),
            scratches: pget(v, 2, 0.3).clamp(0.0, 1.0),
            dust: pget(v, 3, 0.3).clamp(0.0, 1.0),
            flicker: pget(v, 4, 0.2).clamp(0.0, 1.0),
            weave: pget(v, 5, 0.2).clamp(0.0, 1.0),
            seed: pget(v, 6, 0.0).max(0.0).round() as u32,
        }
    }
}

/// Lighten (add > 0) or darken (add < 0) one pixel, weighted by its alpha.
#[inline(always)]
fn touch(out: &mut [f32], o: usize, add: f32) {
    let a = out[o + 3];
    if add >= 0.0 {
        out[o] += add * a;
        out[o + 1] += add * a;
        out[o + 2] += add * a;
    } else {
        let k = (1.0 + add).max(0.0);
        out[o] *= k;
        out[o + 1] *= k;
        out[o + 2] *= k;
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.amount <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let n = w * h;
    let t = time as f32;
    let frame = (time * 24.0).floor() as i64 as u32; // film runs at 24
    let seed = p.seed;
    let orig = px[..n * 4].to_vec();
    let mut out = vec![0.0f32; n * 4];

    // Gate weave: the whole frame jitters by a pixel or two.
    let wx = (p.weave * 2.0 * scale * noise::fbm1(t * 6.0, 2, 21, seed)).round() as i32;
    let wy = (p.weave * 1.5 * scale * noise::fbm1(t * 6.0, 2, 22, seed)).round() as i32;
    for y in 0..h {
        let sy = (y as i32 - wy).clamp(0, h as i32 - 1) as usize;
        let drow = y * w * 4;
        let srow = sy * w * 4;
        if wx == 0 {
            out[drow..drow + w * 4].copy_from_slice(&orig[srow..srow + w * 4]);
        } else {
            for x in 0..w {
                let sx = (x as i32 - wx).clamp(0, w as i32 - 1) as usize;
                let (d, s) = (drow + x * 4, srow + sx * 4);
                out[d] = orig[s];
                out[d + 1] = orig[s + 1];
                out[d + 2] = orig[s + 2];
                out[d + 3] = orig[s + 3];
            }
        }
    }

    // Flicker (whole-frame exposure change) and grain (one cheap hash per pixel).
    let fl = 1.0 + p.flicker * 0.2 * (noise::rnd(frame, seed, 17) * 2.0 - 1.0);
    let gg = p.grain * 0.3;
    for y in 0..h {
        for x in 0..w {
            let o = (y * w + x) * 4;
            let a = out[o + 3];
            let g = if gg > 0.0 {
                (noise::unit(noise::hash2(x as u32, y as u32, frame ^ seed)) - 0.5) * gg * a
            } else {
                0.0
            };
            out[o] = out[o] * fl + g;
            out[o + 1] = out[o + 1] * fl + g;
            out[o + 2] = out[o + 2] * fl + g;
        }
    }

    // Scratches: thin vertical lines that stay for a few frames.
    let sframe = frame / 3;
    let nscratch = (p.scratches * 5.0).round() as u32;
    for i in 0..nscratch {
        let xr = noise::rnd(sframe, i, seed ^ 0x5C) * w as f32;
        let wid = (0.8 + noise::rnd(sframe, i, seed ^ 0x5D) * 1.2) * scale;
        let y0 = (noise::rnd(sframe, i, seed ^ 0x5E) * 0.5 * h as f32) as usize;
        let y1 = (y0 + ((0.4 + 0.6 * noise::rnd(sframe, i, seed ^ 0x5F)) * h as f32) as usize).min(h);
        let bright = 0.5 * (0.4 + 0.6 * p.scratches);
        let xa = (xr - wid).floor().max(0.0) as usize;
        let xb = ((xr + wid).ceil() as usize).min(w - 1);
        for y in y0..y1 {
            let flick = 0.6 + 0.4 * noise::rnd(y as u32, i, frame);
            for x in xa..=xb {
                let wgt = (1.0 - ((x as f32 + 0.5 - xr).abs() / wid)).max(0.0);
                if wgt > 0.0 {
                    touch(&mut out, (y * w + x) * 4, bright * wgt * flick);
                }
            }
        }
    }

    // Dust: small dark or bright specks that change every frame.
    let ndust = (p.dust * 80.0).round() as u32;
    for i in 0..ndust {
        let cxp = noise::rnd(frame, i, seed ^ 0xD1) * w as f32;
        let cyp = noise::rnd(frame, i, seed ^ 0xD2) * h as f32;
        let r0 = noise::rnd(frame, i, seed ^ 0xD3);
        let r = (0.6 + r0 * r0 * 2.5) * scale;
        let dark = noise::rnd(frame, i, seed ^ 0xD4) > 0.5;
        let ya = (cyp - r).floor().max(0.0) as usize;
        let yb = ((cyp + r).ceil() as usize).min(h - 1);
        let xa = (cxp - r).floor().max(0.0) as usize;
        let xb = ((cxp + r).ceil() as usize).min(w - 1);
        for y in ya..=yb {
            for x in xa..=xb {
                let dx = x as f32 + 0.5 - cxp;
                let dy = y as f32 + 0.5 - cyp;
                let d = (dx * dx + dy * dy).sqrt() / r;
                if d < 1.0 {
                    let wgt = (1.0 - d).sqrt();
                    touch(&mut out, (y * w + x) * 4, if dark { -0.8 * wgt } else { 0.8 * wgt });
                }
            }
        }
    }

    for i in 0..n * 4 {
        let v = orig[i] + (out[i].max(0.0) - orig[i]) * p.amount;
        px[i] = if v.is_finite() { v } else { orig[i] };
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke_everything_on() {
        let (w, h) = (96, 64);
        let mut px = suffer_common::test_image(w, h);
        let before = px.clone();
        render(&mut px, w, h, 1.3, 1.0, &Params::from_slice(&[1.0, 1.0, 1.0, 1.0, 1.0, 1.0]));
        assert!(px.iter().all(|v| v.is_finite()));
        assert_ne!(px, before);
    }
    #[test]
    fn amount_zero_is_a_no_op() {
        let (w, h) = (32, 32);
        let mut px = suffer_common::test_image(w, h);
        let before = px.clone();
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[0.0]));
        assert_eq!(px, before);
    }
}
