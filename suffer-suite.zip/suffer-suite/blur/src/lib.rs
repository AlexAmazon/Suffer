//! Suffer Blur: Gaussian-style blur with separate horizontal and vertical size.
//! Big blurs are done at reduced resolution (a blur hides the difference), so the
//! cost stays roughly flat no matter how large the Size is.
use suffer_common::{export_effect, img, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.blur",
  "name": "Suffer Blur",
  "category": "Suffer",
  "params": [
    { "id": "size_x", "name": "Blur Size X", "type": "slider", "default": 10.0, "min": 0.0, "max": 300.0 },
    { "id": "size_y", "name": "Blur Size Y", "type": "slider", "default": 10.0, "min": 0.0, "max": 300.0 }
  ]
}"#;

pub struct Params {
    pub size_x: f32,
    pub size_y: f32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            size_x: pget(v, 0, 10.0).clamp(0.0, 1000.0),
            size_y: pget(v, 1, 10.0).clamp(0.0, 1000.0),
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, scale: f32, p: &Params) {
    if w < 2 || h < 2 || px.len() < w * h * 4 {
        return;
    }
    let n = w * h * 4;
    let sx = p.size_x * scale * 0.5;
    let sy = p.size_y * scale * 0.5;
    if !(sx > 0.3) && !(sy > 0.3) {
        return;
    }
    // Only reduce when BOTH directions are blurred enough that the lost detail cannot show.
    let div = img::pow2_div(sx.min(sy) / 4.0, 16);
    if div > 1 {
        let (mut small, sw, sh) = img::reduce(&px[..n], w, h, 4, div);
        let d = div as f32;
        img::gauss_blur_xy(&mut small, sw, sh, 4, sx / d, sy / d);
        let up = img::upsample4(&small, sw, sh, w, h);
        px[..n].copy_from_slice(&up);
    } else {
        img::gauss_blur_xy(&mut px[..n], w, h, 4, sx, sy);
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (48, 40);
        for size in [0.0, 2.0, 40.0] {
            let mut px = suffer_common::test_image(w, h);
            render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[size, size]));
            assert!(px.iter().all(|v| v.is_finite()));
        }
    }
}
