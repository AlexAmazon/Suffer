//! Suffer VHS Damage: an original, fully procedural analog-tape look.
//!
//! Pipeline (every stage is controlled by its own amount; 0 = off):
//!   1. per-row horizontal displacement: wobble, tracking band, head-switching
//!      noise at the bottom, and a combing offset on odd lines
//!   2. RGB -> YIQ
//!   3. chroma bleed (horizontal blur + shift of I/Q) and luma softening
//!   4. tape noise and dropout streaks
//!   5. scanlines
//!   6. YIQ -> RGB and mix with the original by Amount
//!
//! Speed: real VHS is low resolution, so by default (Resolution = 2) the whole
//! effect runs on a half-size copy and is then scaled back up. Resolution 1 is full
//! quality, 4 is quarter size. Blurs use the fast box blur and noise uses a cheap hash.
use suffer_common::{export_effect, img, noise, pget};
use std::f32::consts::PI;

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.vhs_damage",
  "name": "Suffer VHS Damage",
  "category": "Suffer",
  "params": [
    { "id": "amount",       "name": "Amount",            "type": "slider", "default": 1.0,  "min": 0.0, "max": 1.0 },
    { "id": "tracking",     "name": "Tracking Errors",   "type": "slider", "default": 0.5,  "min": 0.0, "max": 1.0 },
    { "id": "tracking_size","name": "Tracking Band Size","type": "slider", "default": 0.06, "min": 0.0, "max": 0.3 },
    { "id": "combing",      "name": "Interlace Combing", "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "chroma_bleed", "name": "Color Bleed",       "type": "slider", "default": 0.6,  "min": 0.0, "max": 1.0 },
    { "id": "luma_soften",  "name": "Softness",          "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "noise",        "name": "Tape Noise",        "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "dropouts",     "name": "Dropouts",          "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "scanlines",    "name": "Scanlines",         "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "wobble",       "name": "Wobble",            "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "seed",         "name": "Random Seed",       "type": "slider", "default": 0.0,  "min": 0.0, "max": 100.0 },
    { "id": "resolution",   "name": "Resolution (1=full, 2=half, 4=quarter)", "type": "slider", "default": 2.0, "min": 1.0, "max": 4.0 }
  ]
}"#;

#[derive(Clone, Debug)]
pub struct Params {
    pub amount: f32,
    pub tracking: f32,
    pub tracking_size: f32, // fraction of frame height
    pub combing: f32,
    pub chroma_bleed: f32,
    pub luma_soften: f32,
    pub noise: f32,
    pub dropouts: f32,
    pub scanlines: f32,
    pub wobble: f32,
    pub seed: u32,
    pub resolution: usize, // 1, 2 or 4
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        let res = pget(v, 11, 2.0);
        Params {
            amount: pget(v, 0, 1.0).clamp(0.0, 1.0),
            tracking: pget(v, 1, 0.5).clamp(0.0, 1.0),
            tracking_size: pget(v, 2, 0.06).clamp(0.0, 0.3),
            combing: pget(v, 3, 0.3).clamp(0.0, 1.0),
            chroma_bleed: pget(v, 4, 0.6).clamp(0.0, 1.0),
            luma_soften: pget(v, 5, 0.3).clamp(0.0, 1.0),
            noise: pget(v, 6, 0.3).clamp(0.0, 1.0),
            dropouts: pget(v, 7, 0.3).clamp(0.0, 1.0),
            scanlines: pget(v, 8, 0.3).clamp(0.0, 1.0),
            wobble: pget(v, 9, 0.3).clamp(0.0, 1.0),
            seed: pget(v, 10, 0.0).max(0.0).round() as u32,
            resolution: if res >= 3.0 { 4 } else if res >= 1.5 { 2 } else { 1 },
        }
    }
}

/// Horizontal displacement, in pixels, for every row of the frame.
fn row_offsets(h: usize, t: f32, scale: f32, frame: u32, p: &Params) -> Vec<f32> {
    let hf = h as f32;
    let seed = p.seed;
    let seedf = seed as f32;

    // The tracking band drifts down the frame over time.
    let band_c = (t * 0.12 + seedf * 0.37).rem_euclid(1.0) * hf;
    let band_h = (p.tracking_size * hf).max(1.0);

    let mut out = Vec::with_capacity(h);
    for y in 0..h {
        let yf = y as f32;
        let mut dx = 0.0f32;

        if p.wobble > 0.0 {
            let slow = 0.6 * (yf * 0.021 + t * 2.3).sin() + 0.4 * (yf * 0.067 - t * 5.1).sin();
            let jitter = noise::vnoise(yf * 0.5, frame, seed) * 2.0 - 1.0;
            dx += p.wobble * scale * (2.0 * slow + 0.6 * jitter);
        }

        if p.tracking > 0.0 {
            let d = (yf - band_c).abs() / band_h;
            let win = (1.0 - d).clamp(0.0, 1.0);
            let win = win * win * (3.0 - 2.0 * win);
            if win > 0.0 {
                let tear = noise::vnoise(yf * 0.25, frame, seed.wrapping_add(1)) * 2.0 - 1.0;
                dx += p.tracking * 50.0 * scale * win * (tear + 0.6);
            }
            let bottom = ((yf - hf * 0.97) / (hf * 0.03)).clamp(0.0, 1.0);
            if bottom > 0.0 {
                let hs = noise::vnoise(yf * 0.8, frame, seed.wrapping_add(2)) * 2.0 - 1.0;
                dx += p.tracking * 70.0 * scale * bottom * (hs + 0.5);
            }
        }

        // Combing approximation: odd lines sit slightly off the even ones.
        if p.combing > 0.0 && y % 2 == 1 {
            dx += p.combing * 3.0 * scale * (0.5 + 0.5 * noise::vnoise(t * 1.5, 7, seed));
        }

        out.push(dx);
    }
    out
}

/// The effect itself at 100% mix. `orig` is premultiplied RGBA; returns a new buffer.
fn core(orig: &[f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) -> Vec<f32> {
    let t = time as f32;
    let frame = (time * 30.0).floor() as i64 as u32;
    let seed = p.seed;
    let n = w * h;

    // 1. Row displacement (premultiplied RGBA, linear interpolation).
    let offs = row_offsets(h, t, scale, frame, p);
    let mut shifted = vec![0.0f32; n * 4];
    let maxx = (w - 1) as f32;
    for y in 0..h {
        let dx = offs[y];
        let rowo = y * w * 4;
        if dx.abs() < 1e-3 {
            shifted[rowo..rowo + w * 4].copy_from_slice(&orig[rowo..rowo + w * 4]);
            continue;
        }
        for x in 0..w {
            let sx = (x as f32 - dx).clamp(0.0, maxx);
            let x0 = sx as usize;
            let x1 = (x0 + 1).min(w - 1);
            let f = sx - x0 as f32;
            let a = rowo + x0 * 4;
            let b = rowo + x1 * 4;
            let o = rowo + x * 4;
            for c in 0..4 {
                shifted[o + c] = orig[a + c] + (orig[b + c] - orig[a + c]) * f;
            }
        }
    }

    // 2. Unpremultiply and convert to YIQ.
    let mut yp = vec![0.0f32; n];
    let mut ip = vec![0.0f32; n];
    let mut qp = vec![0.0f32; n];
    for i in 0..n {
        let o = i * 4;
        let a = shifted[o + 3];
        if a > 1e-4 {
            let inv = 1.0 / a;
            let (r, g, b) = (shifted[o] * inv, shifted[o + 1] * inv, shifted[o + 2] * inv);
            yp[i] = 0.299 * r + 0.587 * g + 0.114 * b;
            ip[i] = 0.596 * r - 0.274 * g - 0.322 * b;
            qp[i] = 0.211 * r - 0.523 * g + 0.312 * b;
        }
    }

    // 3. Colour bleed and softness (fast box blurs along each row).
    let chroma_r = (p.chroma_bleed * 6.0 * scale).round() as usize;
    let chroma_shift = ((p.chroma_bleed * 2.0 * scale).round() as usize).min(w - 1);
    let luma_r = (p.luma_soften * 1.5 * scale).round() as usize;
    let sat = 1.0 - 0.2 * p.chroma_bleed;
    if chroma_r > 0 {
        for plane in [&mut ip, &mut qp] {
            img::box_blur(plane, w, h, 1, chroma_r, 0);
            img::box_blur(plane, w, h, 1, chroma_r, 0);
        }
    }
    if luma_r > 0 {
        img::box_blur(&mut yp, w, h, 1, luma_r, 0);
    }
    for plane in [&mut ip, &mut qp] {
        for y in 0..h {
            let row = &mut plane[y * w..(y + 1) * w];
            if chroma_shift > 0 {
                let first = row[0];
                row.copy_within(0..w - chroma_shift, chroma_shift);
                for v in row[..chroma_shift].iter_mut() {
                    *v = first;
                }
            }
            for v in row.iter_mut() {
                *v *= sat;
            }
        }
    }

    // 4a. Tape noise: horizontally smeared luma noise, finer chroma noise.
    if p.noise > 0.0 {
        let inv_grain = 1.0 / (1.5 * scale).max(1.0);
        let ng = p.noise;
        for y in 0..h {
            let ry = y as u32;
            for x in 0..w {
                let cell = (x as f32 * inv_grain) as u32;
                let hh = noise::hash2(cell, ry, frame ^ seed);
                let nl = noise::unit(hh) * 2.0 - 1.0;
                let nc = (hh & 0xFF) as f32 * (1.0 / 127.5) - 1.0;
                let i = y * w + x;
                yp[i] += nl * ng * 0.2;
                ip[i] += nc * ng * 0.05;
                qp[i] += nc * ng * 0.05;
            }
        }
    }

    // 4b. Dropouts: short bright streaks with a fading tail, colour drained.
    if p.dropouts > 0.0 {
        for y in 0..h {
            let hit = noise::rnd(y as u32, frame, seed ^ 0xD00D);
            if hit >= p.dropouts * 0.02 {
                continue;
            }
            let start = (noise::rnd(y as u32, frame, seed ^ 0xBEEF) * w as f32) as usize;
            let len = (20.0 + noise::rnd(y as u32, frame, seed ^ 0xCAFE) * 140.0) * scale;
            let rows = if noise::rnd(y as u32, frame, seed ^ 0xF00D) > 0.5 { 1 } else { 2 };
            for yy in y..(y + rows).min(h) {
                for k in 0..(len as usize) {
                    let x = start + k;
                    if x >= w {
                        break;
                    }
                    let fade = (-3.0 * k as f32 / len).exp();
                    let i = yy * w + x;
                    yp[i] += 0.9 * fade;
                    ip[i] *= 1.0 - fade;
                    qp[i] *= 1.0 - fade;
                }
            }
        }
    }

    // 5. Scanlines: darken every other line (period scales with resolution).
    if p.scanlines > 0.0 {
        for y in 0..h {
            let m = 0.5 + 0.5 * (PI * y as f32 / scale).cos();
            let k = 1.0 - p.scanlines * 0.3 * m;
            for v in &mut yp[y * w..(y + 1) * w] {
                *v *= k;
            }
        }
    }

    // 6. Back to RGB and re-premultiply.
    let mut out = vec![0.0f32; n * 4];
    for i in 0..n {
        let a = shifted[i * 4 + 3];
        let (yv, iv, qv) = (yp[i], ip[i], qp[i]);
        let o = i * 4;
        out[o] = (yv + 0.956 * iv + 0.621 * qv).max(0.0) * a;
        out[o + 1] = (yv - 0.272 * iv - 0.647 * qv).max(0.0) * a;
        out[o + 2] = (yv - 1.106 * iv + 1.703 * qv).max(0.0) * a;
        out[o + 3] = a;
    }
    out
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.amount <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let n4 = w * h * 4;
    let div = p.resolution;
    let result: Vec<f32> = if div > 1 {
        let (small, sw, sh) = img::reduce(&px[..n4], w, h, 4, div);
        if sw >= 4 && sh >= 4 {
            let out = core(&small, sw, sh, time, scale / div as f32, p);
            img::upsample4(&out, sw, sh, w, h)
        } else {
            core(&px[..n4], w, h, time, scale, p)
        }
    } else {
        core(&px[..n4], w, h, time, scale, p)
    };
    let amount = p.amount;
    for i in 0..n4 {
        let v = px[i] + (result[i] - px[i]) * amount;
        if v.is_finite() {
            px[i] = v;
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn output_is_finite_and_changes_the_image_at_every_resolution() {
        for res in [1.0, 2.0, 4.0] {
            let (w, h) = (96, 64);
            let mut px = suffer_common::test_image(w, h);
            let before = px.clone();
            let mut params = vec![1.0, 0.5, 0.06, 0.3, 0.6, 0.3, 0.3, 0.3, 0.3, 0.3, 0.0];
            params.push(res);
            render(&mut px, w, h, 1.25, 1.0, &Params::from_slice(&params));
            assert!(px.iter().all(|v| v.is_finite()));
            assert_ne!(px, before);
        }
    }

    #[test]
    fn amount_zero_is_a_no_op() {
        let (w, h) = (32, 32);
        let mut px = suffer_common::test_image(w, h);
        let before = px.clone();
        render(&mut px, w, h, 0.5, 1.0, &Params::from_slice(&[0.0]));
        assert_eq!(px, before);
    }

    #[test]
    fn same_time_same_result_different_time_differs() {
        let (w, h) = (64, 48);
        let p = Params::from_slice(&[]);
        let mut a = suffer_common::test_image(w, h);
        let mut b = suffer_common::test_image(w, h);
        let mut c = suffer_common::test_image(w, h);
        render(&mut a, w, h, 2.0, 1.0, &p);
        render(&mut b, w, h, 2.0, 1.0, &p);
        render(&mut c, w, h, 3.0, 1.0, &p);
        assert_eq!(a, b);
        assert_ne!(a, c);
    }

    #[test]
    fn tiny_frames_do_not_panic() {
        for (w, h) in [(1, 1), (3, 3), (4, 4), (5, 2), (9, 9)] {
            let mut px = vec![0.5f32; w * h * 4];
            render(&mut px, w, h, 0.0, 1.0, &Params::from_slice(&[]));
            assert!(px.iter().all(|v| v.is_finite()));
        }
    }
}
