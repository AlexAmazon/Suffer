//! Suffer Shake: procedural camera shake (translation, rotation, zoom) with
//! motion blur and optional auto-scale so the edges stay covered.
//! Speed: source positions are stepped along each row instead of recomputed,
//! sampling uses the fast interior path, and motion blur uses at most 6 samples.
use suffer_common::{export_effect, img, noise, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.shake",
  "name": "Suffer Shake",
  "category": "Suffer",
  "params": [
    { "id": "frequency",   "name": "Frequency",    "type": "slider", "default": 3.0,  "min": 0.0, "max": 30.0 },
    { "id": "amount_x",    "name": "Amount X",     "type": "slider", "default": 15.0, "min": 0.0, "max": 500.0 },
    { "id": "amount_y",    "name": "Amount Y",     "type": "slider", "default": 15.0, "min": 0.0, "max": 500.0 },
    { "id": "rotation",    "name": "Rotation",     "type": "slider", "default": 1.0,  "min": 0.0, "max": 45.0 },
    { "id": "zoom",        "name": "Zoom Percent", "type": "slider", "default": 0.0,  "min": 0.0, "max": 50.0 },
    { "id": "detail",      "name": "Detail",       "type": "slider", "default": 2.0,  "min": 1.0, "max": 4.0 },
    { "id": "motion_blur", "name": "Motion Blur",  "type": "slider", "default": 0.5,  "min": 0.0, "max": 1.0 },
    { "id": "auto_scale",  "name": "Auto Scale",   "type": "slider", "default": 1.0,  "min": 0.0, "max": 1.0 },
    { "id": "edge_smear",  "name": "Edge Smear",   "type": "slider", "default": 0.0,  "min": 0.0, "max": 1.0 },
    { "id": "seed",        "name": "Random Seed",  "type": "slider", "default": 0.0,  "min": 0.0, "max": 100.0 }
  ]
}"#;

pub struct Params {
    pub frequency: f32,
    pub amount_x: f32,
    pub amount_y: f32,
    pub rotation: f32, // degrees
    pub zoom: f32,     // percent
    pub detail: u32,
    pub blur: f32,
    pub auto_scale: f32,
    pub edge_smear: f32,
    pub seed: u32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            frequency: pget(v, 0, 3.0).clamp(0.0, 100.0),
            amount_x: pget(v, 1, 15.0).clamp(0.0, 5000.0),
            amount_y: pget(v, 2, 15.0).clamp(0.0, 5000.0),
            rotation: pget(v, 3, 1.0).clamp(0.0, 90.0),
            zoom: pget(v, 4, 0.0).clamp(0.0, 90.0),
            detail: (pget(v, 5, 2.0).round() as i64).clamp(1, 4) as u32,
            blur: pget(v, 6, 0.5).clamp(0.0, 1.0),
            auto_scale: pget(v, 7, 1.0).clamp(0.0, 1.0),
            edge_smear: pget(v, 8, 0.0).clamp(0.0, 1.0),
            seed: pget(v, 9, 0.0).max(0.0).round() as u32,
        }
    }
}

struct Tf {
    cos: f32,
    sin: f32,
    inv_s: f32,
    tx: f32,
    ty: f32,
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || px.len() < w * h * 4 {
        return;
    }
    if p.amount_x <= 0.0 && p.amount_y <= 0.0 && p.rotation <= 0.0 && p.zoom <= 0.0 {
        return;
    }
    let orig = px[..w * h * 4].to_vec();
    let cx = w as f32 * 0.5;
    let cy = h as f32 * 0.5;

    // Motion blur = average of a few shake positions across a short shutter.
    let n = 1 + (p.blur * 5.0).round() as usize;
    let shutter = p.blur as f64 / 30.0;

    // Zoom in enough that the moving frame never shows past the layer edge.
    let rot_max = p.rotation.to_radians().abs();
    let cover = 1.0
        + 2.0 * p.amount_x * scale / w as f32
        + 2.0 * p.amount_y * scale / h as f32
        + rot_max * 1.2
        + p.zoom * 0.01;
    let auto = 1.0 + p.auto_scale * (cover - 1.0);

    let mut tfs: Vec<Tf> = Vec::with_capacity(n);
    for k in 0..n {
        let frac = if n > 1 { k as f64 / (n - 1) as f64 - 0.5 } else { 0.0 };
        let tau = ((time + frac * shutter) as f32) * p.frequency;
        let tx = p.amount_x * scale * noise::fbm1(tau, p.detail, 1, p.seed);
        let ty = p.amount_y * scale * noise::fbm1(tau, p.detail, 2, p.seed);
        let rot = p.rotation.to_radians() * noise::fbm1(tau, p.detail, 3, p.seed);
        let zoom = 1.0 + p.zoom * 0.01 * noise::fbm1(tau, p.detail, 4, p.seed);
        tfs.push(Tf {
            cos: rot.cos(),
            sin: rot.sin(),
            inv_s: 1.0 / (zoom * auto).max(0.01),
            tx,
            ty,
        });
    }

    let clamp_edge = p.edge_smear > 0.5;
    let inv_n = 1.0 / n as f32;
    let mut row = vec![0.0f32; w * 4];
    for y in 0..h {
        for v in row.iter_mut() {
            *v = 0.0;
        }
        for tf in &tfs {
            // Source position is linear in x, so compute it once per row and step it.
            let dy = y as f32 - cy - tf.ty;
            let x0 = -cx - tf.tx;
            let mut sx = cx + tf.inv_s * (tf.cos * x0 + tf.sin * dy);
            let mut sy = cy + tf.inv_s * (-tf.sin * x0 + tf.cos * dy);
            let dsx = tf.inv_s * tf.cos;
            let dsy = -tf.inv_s * tf.sin;
            for x in 0..w {
                let s = img::bilerp4(&orig, w, h, sx, sy, clamp_edge);
                let o = x * 4;
                row[o] += s[0];
                row[o + 1] += s[1];
                row[o + 2] += s[2];
                row[o + 3] += s[3];
                sx += dsx;
                sy += dsy;
            }
        }
        let base = y * w * 4;
        for i in 0..w * 4 {
            px[base + i] = row[i] * inv_n;
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (48, 40);
        let mut px = suffer_common::test_image(w, h);
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[]));
        assert!(px.iter().all(|v| v.is_finite()));
    }
    #[test]
    fn zero_motion_is_a_no_op() {
        let (w, h) = (32, 24);
        let mut px = suffer_common::test_image(w, h);
        let before = px.clone();
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[3.0, 0.0, 0.0, 0.0, 0.0]));
        assert_eq!(px, before);
    }
}
