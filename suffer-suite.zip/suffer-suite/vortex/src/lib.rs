//! Suffer Vortex: twists the image around a point. The twist is worked out on a
//! reduced grid (it is smooth) and applied with one sample per pixel.
use suffer_common::lens::Field;
use suffer_common::{export_effect, img, pget};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.vortex",
  "name": "Suffer Vortex",
  "category": "Suffer",
  "params": [
    { "id": "twist",    "name": "Twist",    "type": "slider", "default": 90.0,  "min": -720.0, "max": 720.0 },
    { "id": "radius",   "name": "Radius",   "type": "slider", "default": 300.0, "min": 1.0,    "max": 3000.0 },
    { "id": "center_x", "name": "Center X", "type": "slider", "default": 0.5,   "min": 0.0,    "max": 1.0 },
    { "id": "center_y", "name": "Center Y", "type": "slider", "default": 0.5,   "min": 0.0,    "max": 1.0 },
    { "id": "falloff",  "name": "Falloff",  "type": "slider", "default": 2.0,   "min": 0.5,    "max": 6.0 }
  ]
}"#;

pub struct Params {
    pub twist: f32, // radians
    pub radius: f32,
    pub center_x: f32,
    pub center_y: f32,
    pub falloff: f32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            twist: pget(v, 0, 90.0).clamp(-720.0, 720.0).to_radians(),
            radius: pget(v, 1, 300.0).clamp(1.0, 20000.0),
            center_x: pget(v, 2, 0.5),
            center_y: pget(v, 3, 0.5),
            falloff: pget(v, 4, 2.0).clamp(0.5, 6.0),
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, _time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.twist == 0.0 || px.len() < w * h * 4 {
        return;
    }
    let radius = p.radius * scale;
    let cx = p.center_x * w as f32;
    let cy = p.center_y * h as f32;
    let div = img::pow2_div(radius / 40.0, 8);
    let df = div as f32;
    let (rw, rh) = img::reduced_size(w, h, div);

    // Displacement (in full-resolution pixels) at every point of the reduced grid.
    let mut f = Field::zeros(rw, rh, div);
    for y in 0..rh {
        let yf = (y as f32 + 0.5) * df - 0.5;
        for x in 0..rw {
            let xf = (x as f32 + 0.5) * df - 0.5;
            let dx = xf - cx;
            let dy = yf - cy;
            let r = (dx * dx + dy * dy).sqrt();
            if r >= radius {
                continue;
            }
            let ang = p.twist * (1.0 - r / radius).powf(p.falloff);
            let (s, c) = ang.sin_cos();
            let i = y * rw + x;
            f.gx[i] = c * dx - s * dy - dx;
            f.gy[i] = s * dx + c * dy - dy;
        }
    }

    let orig = px[..w * h * 4].to_vec();
    for y in 0..h {
        for x in 0..w {
            let (dx, dy) = f.at(x as f32, y as f32);
            if dx.abs() + dy.abs() < 0.01 {
                continue;
            }
            let v = img::bilerp4(&orig, w, h, x as f32 + dx, y as f32 + dy, true);
            let o = (y * w + x) * 4;
            px[o] = v[0];
            px[o + 1] = v[1];
            px[o + 2] = v[2];
            px[o + 3] = v[3];
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke_and_zero_twist() {
        let (w, h) = (64, 48);
        let mut px = suffer_common::test_image(w, h);
        let before = px.clone();
        render(&mut px, w, h, 0.0, 1.0, &Params::from_slice(&[90.0, 40.0]));
        assert!(px.iter().all(|v| v.is_finite()));
        assert_ne!(px, before);
        let mut same = before.clone();
        render(&mut same, w, h, 0.0, 1.0, &Params::from_slice(&[0.0]));
        assert_eq!(same, before);
    }
}
