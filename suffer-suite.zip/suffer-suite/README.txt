SUFFER - effects for EffectCraft (plug-in API v1, WebAssembly)

BUILD
 1. Install Rust from rustup.rs (once). Reopen Visual Studio afterwards.
 2. Open View > Terminal in Visual Studio, then:
        cd C:\suffer-suite        (wherever you extracted this folder)
        .\build.bat
 3. Finished plug-ins appear in the "dist" folder.
 4. In EffectCraft: Effect > Load Effect Plug-in...  and pick a .wasm file.

If one effect fails to build, the others still build. The script lists which
failed; send the red error text for that one.

EFFECTS (17)
 glint_rainbow    Glint Rainbow          glint           Glint
 glow             Glow                   rays            Rays
 shake            Shake                  waves           Waves
 vortex           Vortex                 blur            Blur
 blur_directional Directional Blur       distort         Distort
 distort_rgb      Distort RGB            distort_chroma  Distort Chroma
 distort_blur     Distort Blur           vhs_damage      VHS Damage
 tv_damage        TV Damage              film_damage     Film Damage
 edge_detect      Edge Detect            duotone         Duotone

SPEED NOTES
 Plug-ins run in an interpreter, so the suite is built around doing less work:
 - Big blurs, glints, rays, glow and the Distort lens run at reduced resolution.
 - VHS Damage has a Resolution slider (1 = full, 2 = half, 4 = quarter). Default is 2.
 - If something is still slow, lower its Samples / Motion Blur, or raise VHS Resolution.

The Distort family builds its own "lens" (Lens Mode: 0 = the image's own
brightness, 1 = animated noise, 2 = a round bump) because API v1 gives an
effect only one image.

ADDING AN EFFECT
 Copy any effect folder that uses suffer_common (for example "blur"), rename it,
 edit its src\lib.rs, then add the folder name to Cargo.toml and build.bat.
