//! Small colour helpers.

pub fn luma(r: f32, g: f32, b: f32) -> f32 {
    0.2126 * r + 0.7152 * g + 0.0722 * b
}

pub fn rgb_to_yiq(r: f32, g: f32, b: f32) -> (f32, f32, f32) {
    (
        0.299 * r + 0.587 * g + 0.114 * b,
        0.596 * r - 0.274 * g - 0.322 * b,
        0.211 * r - 0.523 * g + 0.312 * b,
    )
}

pub fn yiq_to_rgb(y: f32, i: f32, q: f32) -> (f32, f32, f32) {
    (
        y + 0.956 * i + 0.621 * q,
        y - 0.272 * i - 0.647 * q,
        y - 1.106 * i + 1.703 * q,
    )
}

/// h in 0..1 (wraps), s and v in 0..1.
pub fn hsv_to_rgb(h: f32, s: f32, v: f32) -> [f32; 3] {
    let h = h - h.floor();
    let f = |n: f32| -> f32 {
        let k = (n + h * 6.0) % 6.0;
        v - v * s * k.min(4.0 - k).min(1.0).max(0.0)
    };
    [f(5.0), f(3.0), f(1.0)]
}

/// Smooth rainbow: R, G, B cosine lobes 120 degrees apart. h wraps at 1.
pub fn spectrum(h: f32) -> [f32; 3] {
    let h = h - h.floor();
    let lobe = |o: f32| 0.5 + 0.5 * (2.0 * std::f32::consts::PI * (h - o)).cos();
    [lobe(0.0), lobe(1.0 / 3.0), lobe(2.0 / 3.0)]
}
