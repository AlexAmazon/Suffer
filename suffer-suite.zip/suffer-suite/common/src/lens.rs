//! A built-in "lens" for the Distort family.
//!
//! Sapphire's Distort effects use a second input layer (the Lens) and push pixels
//! along the gradient of its brightness. Plug-in API v1 gives an effect only one
//! image, so Suffer builds the lens itself. Three choices:
//!   0 = the source's own brightness (edges bend / smear / split)
//!   1 = animated fractal noise (glass, water, heat shimmer)
//!   2 = a round bump in the centre of the frame (a single lens)
//!
//! Speed: the lens is smooth by nature, so it is computed on a reduced grid and the
//! result is a `Field` that is sampled bilinearly at full resolution.

use crate::{img, noise, pget};

#[derive(Clone, Debug)]
pub struct LensParams {
    pub mode: u32,
    pub size: f32,  // feature size in pixels (modes 1 and 2)
    pub soft: f32,  // blur applied to the lens before taking its gradient, in pixels
    pub speed: f32, // how fast the noise lens morphs (changes per second)
    pub seed: u32,
}

impl LensParams {
    /// Reads five consecutive parameters starting at index `first`:
    /// lens mode, lens size, lens softness, lens speed, seed.
    pub fn from_slice(v: &[f64], first: usize) -> Self {
        LensParams {
            mode: pget(v, first, 0.0).round().clamp(0.0, 2.0) as u32,
            size: pget(v, first + 1, 120.0).clamp(1.0, 4000.0),
            soft: pget(v, first + 2, 6.0).clamp(0.0, 400.0),
            speed: pget(v, first + 3, 0.2).clamp(0.0, 20.0),
            seed: pget(v, first + 4, 0.0).max(0.0).round() as u32,
        }
    }
}

/// A pair of 2-D planes stored at reduced resolution and read back at full-resolution coordinates.
pub struct Field {
    pub gx: Vec<f32>,
    pub gy: Vec<f32>,
    pub w: usize, // reduced width
    pub h: usize, // reduced height
    pub div: f32, // full-resolution pixels per reduced pixel
    inv: f32,
}

impl Field {
    pub fn zeros(w: usize, h: usize, div: usize) -> Self {
        Field {
            gx: vec![0.0; w * h],
            gy: vec![0.0; w * h],
            w,
            h,
            div: div as f32,
            inv: 1.0 / div as f32,
        }
    }

    /// Value of the field at a full-resolution pixel position.
    #[inline(always)]
    pub fn at(&self, x: f32, y: f32) -> (f32, f32) {
        let sx = (x + 0.5) * self.inv - 0.5;
        let sy = (y + 0.5) * self.inv - 0.5;
        (
            img::bilerp1(&self.gx, self.w, self.h, sx, sy),
            img::bilerp1(&self.gy, self.w, self.h, sx, sy),
        )
    }
}

/// Per-pixel lens gradient, roughly -1..1 where the lens slopes most steeply.
/// Multiply by an amount in pixels to get a displacement.
pub fn gradient(px: &[f32], w: usize, h: usize, time: f32, scale: f32, lp: &LensParams) -> Field {
    let size = (lp.size * scale).max(1.0);
    let soft = lp.soft * scale;
    let div = match lp.mode {
        0 => img::pow2_div(soft / 3.0, 8),
        _ => img::pow2_div(size / 10.0, 8),
    };
    let df = div as f32;
    let (rw, rh) = img::reduced_size(w, h, div);
    let n = rw * rh;
    let mut lens = vec![0.0f32; n];

    let k = match lp.mode {
        0 => {
            let (small, _, _) = img::reduce(&px[..w * h * 4], w, h, 4, div);
            for i in 0..n {
                let o = i * 4;
                let l = 0.2126 * small[o] + 0.7152 * small[o + 1] + 0.0722 * small[o + 2];
                lens[i] = if l.is_finite() { l.clamp(0.0, 2.0) } else { 0.0 };
            }
            soft.max(1.0) * 2.0
        }
        1 => {
            let inv = 1.0 / size;
            let tt = time * lp.speed;
            for y in 0..rh {
                let yf = (y as f32 + 0.5) * df * inv;
                for x in 0..rw {
                    let xf = (x as f32 + 0.5) * df * inv;
                    lens[y * rw + x] = noise::fbm2_t(xf, yf, tt, 2, lp.seed);
                }
            }
            size * 0.7
        }
        _ => {
            let cx = w as f32 * 0.5;
            let cy = h as f32 * 0.5;
            for y in 0..rh {
                let dy = ((y as f32 + 0.5) * df - cy) / size;
                for x in 0..rw {
                    let dx = ((x as f32 + 0.5) * df - cx) / size;
                    lens[y * rw + x] = (-(dx * dx + dy * dy)).exp();
                }
            }
            size * 1.2
        }
    };

    img::gauss_blur_xy(&mut lens, rw, rh, 1, soft / df, soft / df);

    let mut f = Field::zeros(rw, rh, div);
    let kk = k / df; // gradient per reduced pixel -> per full-resolution pixel
    for y in 0..rh {
        let ym = y.saturating_sub(1);
        let yp = (y + 1).min(rh - 1);
        let dy = (yp - ym).max(1) as f32;
        for x in 0..rw {
            let xm = x.saturating_sub(1);
            let xp = (x + 1).min(rw - 1);
            let dx = (xp - xm).max(1) as f32;
            let i = y * rw + x;
            f.gx[i] = ((lens[y * rw + xp] - lens[y * rw + xm]) / dx * kk).clamp(-1.5, 1.5);
            f.gy[i] = ((lens[yp * rw + x] - lens[ym * rw + x]) / dy * kk).clamp(-1.5, 1.5);
        }
    }
    f
}
