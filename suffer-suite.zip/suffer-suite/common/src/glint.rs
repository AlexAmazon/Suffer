//! Shared engine for Glint and Glint Rainbow.
//!
//! Bright spots become emitters; each emitter draws `rays` lines (two arms each)
//! that fade out with distance. For Glint Rainbow the colour also cycles through
//! the spectrum along each arm. Rays are drawn at reduced resolution and then
//! expanded, which keeps the cost low and the rays smooth.

use crate::{color, img};
use std::f32::consts::PI;

#[derive(Clone, Debug)]
pub struct GlintCfg {
    pub threshold: f32,
    pub brightness: f32,
    pub size: f32, // ray length in pixels at 100% resolution
    pub cycles: f32,
    pub hue_offset: f32,
    pub rays: usize,
    pub angle: f32, // radians
    pub saturation: f32,
    pub color_mix: f32, // 0 = pure ray colour, 1 = tinted by the source
    pub rainbow: bool,
}

const MAX_SOURCES: usize = 1536;
const GAIN: f32 = 0.5;

struct Src {
    x: f32,
    y: f32,
    energy: f32,
    tint: [f32; 3],
}

fn splat(acc: &mut [f32], w: usize, h: usize, x: f32, y: f32, c: [f32; 3]) {
    let x0 = x.floor();
    let y0 = y.floor();
    let fx = x - x0;
    let fy = y - y0;
    let xi = x0 as i32;
    let yi = y0 as i32;
    if xi < -1 || yi < -1 || xi >= w as i32 || yi >= h as i32 {
        return;
    }
    let taps = [
        (0i32, 0i32, (1.0 - fx) * (1.0 - fy)),
        (1, 0, fx * (1.0 - fy)),
        (0, 1, (1.0 - fx) * fy),
        (1, 1, fx * fy),
    ];
    for (dx, dy, wt) in taps {
        let xx = xi + dx;
        let yy = yi + dy;
        if xx < 0 || yy < 0 || xx >= w as i32 || yy >= h as i32 {
            continue;
        }
        let o = (yy as usize * w + xx as usize) * 4;
        acc[o] += c[0] * wt;
        acc[o + 1] += c[1] * wt;
        acc[o + 2] += c[2] * wt;
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, scale: f32, cfg: &GlintCfg) {
    let size = cfg.size * scale;
    if w < 4 || h < 4 || size < 1.0 || cfg.brightness <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let div = img::pow2_div(size / 48.0, 4);
    let (grid, sw, sh, any) = img::bright_reduce(px, w, h, cfg.threshold, 0.0, div);
    if !any {
        return;
    }
    let cell = (div * div) as f32;
    let divf = div as f32;

    // Pick emitters (every n-th one if there are too many).
    let mut cands = 0usize;
    for i in 0..sw * sh {
        if grid[i * 4] + grid[i * 4 + 1] + grid[i * 4 + 2] > 1e-6 {
            cands += 1;
        }
    }
    if cands == 0 {
        return;
    }
    let stride = ((cands + MAX_SOURCES - 1) / MAX_SOURCES).max(1);
    let mut srcs: Vec<Src> = Vec::with_capacity(cands / stride + 1);
    let mut seen = 0usize;
    for y in 0..sh {
        for x in 0..sw {
            let o = (y * sw + x) * 4;
            let (r, g, b) = (grid[o], grid[o + 1], grid[o + 2]);
            let l = color::luma(r, g, b);
            if !(l > 1e-6) {
                continue;
            }
            let keep = seen % stride == 0;
            seen += 1;
            if !keep {
                continue;
            }
            srcs.push(Src {
                x: x as f32,
                y: y as f32,
                energy: l * cell * stride as f32 / divf,
                tint: [r / l, g / l, b / l],
            });
        }
    }

    // Draw the rays at reduced resolution.
    let mut acc = vec![0.0f32; sw * sh * 4];
    let len_r = size / divf;
    let steps = len_r.ceil() as i32;
    let inv_len = 1.0 / len_r;
    for k in 0..cfg.rays {
        let ang = cfg.angle + PI * (k as f32) / (cfg.rays as f32);
        let (dy, dx) = ang.sin_cos();
        for sign in [-1.0f32, 1.0] {
            for s in 1..=steps {
                let d = s as f32;
                let t = d * inv_len;
                if t > 1.0 {
                    break;
                }
                let fall = (1.0 - t) * (1.0 - t);
                let rb = if cfg.rainbow {
                    let sp = color::spectrum(t * cfg.cycles + cfg.hue_offset);
                    [
                        1.0 + cfg.saturation * (sp[0] - 1.0),
                        1.0 + cfg.saturation * (sp[1] - 1.0),
                        1.0 + cfg.saturation * (sp[2] - 1.0),
                    ]
                } else {
                    [1.0, 1.0, 1.0]
                };
                let ox = sign * dx * d;
                let oy = sign * dy * d;
                for src in &srcs {
                    let amount = src.energy * cfg.brightness * GAIN * fall;
                    let c = [
                        (rb[0] + cfg.color_mix * (src.tint[0] - rb[0])) * amount,
                        (rb[1] + cfg.color_mix * (src.tint[1] - rb[1])) * amount,
                        (rb[2] + cfg.color_mix * (src.tint[2] - rb[2])) * amount,
                    ];
                    splat(&mut acc, sw, sh, src.x + ox, src.y + oy, c);
                }
            }
        }
    }

    // Expand to full resolution and add onto the source. Alpha rises under the glint.
    let inv_div = 1.0 / divf;
    for y in 0..h {
        let sy = (y as f32 + 0.5) * inv_div - 0.5;
        for x in 0..w {
            let sx = (x as f32 + 0.5) * inv_div - 0.5;
            let g = img::bilerp4(&acc, sw, sh, sx, sy, true);
            if g[0] == 0.0 && g[1] == 0.0 && g[2] == 0.0 {
                continue;
            }
            let o = (y * w + x) * 4;
            let (r, gg, b) = (px[o] + g[0], px[o + 1] + g[1], px[o + 2] + g[2]);
            if r.is_finite() && gg.is_finite() && b.is_finite() {
                px[o] = r;
                px[o + 1] = gg;
                px[o + 2] = b;
                px[o + 3] = px[o + 3].max(g[0].max(g[1]).max(g[2]).min(1.0));
            }
        }
    }
}
