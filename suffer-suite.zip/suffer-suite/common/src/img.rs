//! Image buffers are row-major f32. "c" is channels per pixel (4 = premultiplied RGBA).
//! Sampling positions use pixel centres at integer coordinates: (x, y) = pixel (x, y).
//!
//! Speed notes: plug-ins run in an interpreter, so every instruction counts.
//! Sampling has a branch-light interior fast path, blurs are sliding-window and
//! cache-friendly, and `reduce` / `upsample4` let heavy effects work at lower
//! resolution when the result is soft anyway.

#[inline(always)]
fn fetch4(buf: &[f32], w: usize, h: usize, xi: i32, yi: i32, clamp: bool) -> [f32; 4] {
    let (mut x, mut y) = (xi, yi);
    if clamp {
        x = x.clamp(0, w as i32 - 1);
        y = y.clamp(0, h as i32 - 1);
    } else if x < 0 || y < 0 || x >= w as i32 || y >= h as i32 {
        return [0.0; 4];
    }
    let o = (y as usize * w + x as usize) * 4;
    [buf[o], buf[o + 1], buf[o + 2], buf[o + 3]]
}

#[inline(never)]
fn bilerp4_slow(buf: &[f32], w: usize, h: usize, x: f32, y: f32, clamp: bool) -> [f32; 4] {
    let x0 = x.floor();
    let y0 = y.floor();
    let fx = x - x0;
    let fy = y - y0;
    let xi = x0 as i32;
    let yi = y0 as i32;
    let a = fetch4(buf, w, h, xi, yi, clamp);
    let b = fetch4(buf, w, h, xi.saturating_add(1), yi, clamp);
    let c = fetch4(buf, w, h, xi, yi.saturating_add(1), clamp);
    let d = fetch4(buf, w, h, xi.saturating_add(1), yi.saturating_add(1), clamp);
    let mut o = [0.0f32; 4];
    for k in 0..4 {
        let top = a[k] + (b[k] - a[k]) * fx;
        let bot = c[k] + (d[k] - c[k]) * fx;
        o[k] = top + (bot - top) * fy;
    }
    o
}

/// Bilinear sample of an RGBA buffer. `clamp` = repeat the edge; otherwise outside is transparent.
#[inline(always)]
pub fn bilerp4(buf: &[f32], w: usize, h: usize, x: f32, y: f32, clamp: bool) -> [f32; 4] {
    if x >= 0.0 && y >= 0.0 && x < (w as f32 - 1.0) && y < (h as f32 - 1.0) {
        let xi = x as usize;
        let yi = y as usize;
        let fx = x - xi as f32;
        let fy = y - yi as f32;
        let o = (yi * w + xi) * 4;
        let o2 = o + w * 4;
        if o2 + 8 <= buf.len() {
            let mut r = [0.0f32; 4];
            for k in 0..4 {
                // SAFETY: o2 + 8 <= buf.len() was checked above and k < 4, so every index is in range.
                let (a, b, c, d) = unsafe {
                    (
                        *buf.get_unchecked(o + k),
                        *buf.get_unchecked(o + 4 + k),
                        *buf.get_unchecked(o2 + k),
                        *buf.get_unchecked(o2 + 4 + k),
                    )
                };
                let top = a + (b - a) * fx;
                let bot = c + (d - c) * fx;
                r[k] = top + (bot - top) * fy;
            }
            return r;
        }
    }
    bilerp4_slow(buf, w, h, x, y, clamp)
}

#[inline(never)]
fn bilerp1_slow(p: &[f32], w: usize, h: usize, x: f32, y: f32) -> f32 {
    let x0 = x.floor();
    let y0 = y.floor();
    let fx = x - x0;
    let fy = y - y0;
    let xi = x0 as i32;
    let yi = y0 as i32;
    let maxx = w as i32 - 1;
    let maxy = h as i32 - 1;
    let g = |xx: i32, yy: i32| -> f32 {
        let cx = xx.clamp(0, maxx) as usize;
        let cy = yy.clamp(0, maxy) as usize;
        p[cy * w + cx]
    };
    let a = g(xi, yi);
    let b = g(xi.saturating_add(1), yi);
    let c = g(xi, yi.saturating_add(1));
    let d = g(xi.saturating_add(1), yi.saturating_add(1));
    let top = a + (b - a) * fx;
    let bot = c + (d - c) * fx;
    top + (bot - top) * fy
}

/// Bilinear sample of a single-channel plane (edges repeat).
#[inline(always)]
pub fn bilerp1(p: &[f32], w: usize, h: usize, x: f32, y: f32) -> f32 {
    if x >= 0.0 && y >= 0.0 && x < (w as f32 - 1.0) && y < (h as f32 - 1.0) {
        let xi = x as usize;
        let yi = y as usize;
        let fx = x - xi as f32;
        let fy = y - yi as f32;
        let o = yi * w + xi;
        let o2 = o + w;
        if o2 + 2 <= p.len() {
            // SAFETY: o2 + 2 <= p.len() was checked above.
            let (a, b, c, d) = unsafe {
                (
                    *p.get_unchecked(o),
                    *p.get_unchecked(o + 1),
                    *p.get_unchecked(o2),
                    *p.get_unchecked(o2 + 1),
                )
            };
            let top = a + (b - a) * fx;
            let bot = c + (d - c) * fx;
            return top + (bot - top) * fy;
        }
    }
    bilerp1_slow(p, w, h, x, y)
}

// ---------------------------------------------------------------------------
// Blurs
// ---------------------------------------------------------------------------

/// Horizontal box blur of every row (edges repeat). Sliding window over a padded copy of the row.
fn box_h(buf: &mut [f32], w: usize, h: usize, c: usize, r: usize, tmp: &mut Vec<f32>) {
    let n = w * c;
    let inv = 1.0 / (2 * r + 1) as f32;
    for y in 0..h {
        let row = &mut buf[y * n..(y + 1) * n];
        tmp.clear();
        for _ in 0..r {
            tmp.extend_from_slice(&row[0..c]);
        }
        tmp.extend_from_slice(row);
        for _ in 0..r {
            tmp.extend_from_slice(&row[n - c..n]);
        }
        for ch in 0..c {
            let mut sum = 0.0f32;
            for k in 0..(2 * r + 1) {
                sum += tmp[k * c + ch];
            }
            for x in 0..w - 1 {
                row[x * c + ch] = sum * inv;
                sum += tmp[(x + 2 * r + 1) * c + ch] - tmp[x * c + ch];
            }
            row[(w - 1) * c + ch] = sum * inv;
        }
    }
}

/// Vertical box blur, done a whole row at a time so memory is read in order.
fn box_v(buf: &mut [f32], w: usize, h: usize, c: usize, r: usize, src: &mut Vec<f32>) {
    let n = w * c;
    let inv = 1.0 / (2 * r + 1) as f32;
    src.clear();
    src.extend_from_slice(buf);
    let mut sum = vec![0.0f32; n];
    let last = h as i32 - 1;
    for k in -(r as i32)..=(r as i32) {
        let yy = k.clamp(0, last) as usize;
        let row = &src[yy * n..(yy + 1) * n];
        for i in 0..n {
            sum[i] += row[i];
        }
    }
    for y in 0..h {
        let out = &mut buf[y * n..(y + 1) * n];
        for i in 0..n {
            out[i] = sum[i] * inv;
        }
        if y + 1 < h {
            let add = ((y + r + 1) as i32).min(last) as usize;
            let rem = (y as i32 - r as i32).max(0) as usize;
            let ra = &src[add * n..(add + 1) * n];
            let rr = &src[rem * n..(rem + 1) * n];
            for i in 0..n {
                sum[i] += ra[i] - rr[i];
            }
        }
    }
}

/// Separable box blur with horizontal radius `rx` and vertical radius `ry` (pixels).
pub fn box_blur(buf: &mut [f32], w: usize, h: usize, c: usize, rx: usize, ry: usize) {
    if w < 1 || h < 1 {
        return;
    }
    let mut tmp: Vec<f32> = Vec::new();
    if rx > 0 {
        box_h(buf, w, h, c, rx, &mut tmp);
    }
    if ry > 0 {
        box_v(buf, w, h, c, ry, &mut tmp);
    }
}

fn sigma_to_radius(s: f32) -> usize {
    if !(s > 0.3) {
        return 0;
    }
    let width = (4.0 * s * s + 1.0).sqrt();
    (((width - 1.0) * 0.5).round().max(1.0)).min(4096.0) as usize
}

/// Approximate Gaussian blur (three box passes) with separate horizontal / vertical sigma.
pub fn gauss_blur_xy(buf: &mut [f32], w: usize, h: usize, c: usize, sx: f32, sy: f32) {
    let rx = sigma_to_radius(sx);
    let ry = sigma_to_radius(sy);
    if rx == 0 && ry == 0 {
        return;
    }
    for _ in 0..3 {
        box_blur(buf, w, h, c, rx, ry);
    }
}

// ---------------------------------------------------------------------------
// Resolution changes
// ---------------------------------------------------------------------------

/// Halve the resolution by averaging 2x2 blocks. Returns (pixels, new_w, new_h).
pub fn downsample2(src: &[f32], w: usize, h: usize, c: usize) -> (Vec<f32>, usize, usize) {
    let w2 = ((w + 1) / 2).max(1);
    let h2 = ((h + 1) / 2).max(1);
    let mut out = vec![0.0f32; w2 * h2 * c];
    for y in 0..h2 {
        let y0 = (2 * y).min(h - 1);
        let y1 = (2 * y + 1).min(h - 1);
        for x in 0..w2 {
            let x0 = (2 * x).min(w - 1);
            let x1 = (2 * x + 1).min(w - 1);
            let a = (y0 * w + x0) * c;
            let b = (y0 * w + x1) * c;
            let d = (y1 * w + x0) * c;
            let e = (y1 * w + x1) * c;
            let o = (y * w2 + x) * c;
            for k in 0..c {
                out[o + k] = 0.25 * (src[a + k] + src[b + k] + src[d + k] + src[e + k]);
            }
        }
    }
    (out, w2, h2)
}

/// Size after halving `div` times (div must be a power of two: 1, 2, 4, 8 ...).
pub fn reduced_size(mut w: usize, mut h: usize, div: usize) -> (usize, usize) {
    let mut d = div;
    while d > 1 {
        w = ((w + 1) / 2).max(1);
        h = ((h + 1) / 2).max(1);
        d /= 2;
    }
    (w, h)
}

/// Reduce resolution by a power-of-two factor. Returns (pixels, new_w, new_h).
pub fn reduce(src: &[f32], w: usize, h: usize, c: usize, div: usize) -> (Vec<f32>, usize, usize) {
    let mut cur = src.to_vec();
    let (mut cw, mut ch) = (w, h);
    let mut d = div;
    while d > 1 {
        let (n, nw, nh) = downsample2(&cur, cw, ch, c);
        cur = n;
        cw = nw;
        ch = nh;
        d /= 2;
    }
    (cur, cw, ch)
}

/// Largest power of two <= x, at least 1 and at most `max` (1, 2, 4, 8 ...).
pub fn pow2_div(x: f32, max: usize) -> usize {
    let mut d = 1usize;
    while d * 2 <= max && (d * 2) as f32 <= x {
        d *= 2;
    }
    d
}

/// Resize an RGBA buffer to (dw, dh) with bilinear filtering.
pub fn upsample4(src: &[f32], sw: usize, sh: usize, dw: usize, dh: usize) -> Vec<f32> {
    let mut out = vec![0.0f32; dw * dh * 4];
    let rx = sw as f32 / dw as f32;
    let ry = sh as f32 / dh as f32;
    for y in 0..dh {
        let sy = (y as f32 + 0.5) * ry - 0.5;
        let mut sx = 0.5 * rx - 0.5;
        let row = y * dw * 4;
        for x in 0..dw {
            let v = bilerp4(src, sw, sh, sx, sy, true);
            let o = row + x * 4;
            out[o] = v[0];
            out[o + 1] = v[1];
            out[o + 2] = v[2];
            out[o + 3] = v[3];
            sx += rx;
        }
    }
    out
}

/// Bright-pass and reduce in one go: every pixel's excess over `thr` (with a soft knee)
/// keeps its colour, and the result is averaged into blocks of `div` x `div` pixels.
/// Returns (RGBA pixels, new_w, new_h, anything_was_bright). `div` is any integer >= 1.
pub fn bright_reduce(
    px: &[f32],
    w: usize,
    h: usize,
    thr: f32,
    knee: f32,
    div: usize,
) -> (Vec<f32>, usize, usize, bool) {
    let div = div.max(1);
    let sw = (w + div - 1) / div;
    let sh = (h + div - 1) / div;
    let mut out = vec![0.0f32; sw * sh * 4];
    let cutoff = thr - knee;
    let knee2 = 2.0 * knee;
    let kd = 4.0 * knee + 1e-5;
    let mut any = false;
    for y in 0..h {
        let row = (y / div) * sw;
        for x in 0..w {
            let o = (y * w + x) * 4;
            let (r, g, b) = (px[o], px[o + 1], px[o + 2]);
            let l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
            if !(l > cutoff) || !l.is_finite() || l <= 0.0 {
                continue;
            }
            let soft = (l - thr + knee).clamp(0.0, knee2);
            let soft = soft * soft / kd;
            let contrib = soft.max(l - thr);
            if contrib <= 0.0 {
                continue;
            }
            let s = contrib / l;
            let so = (row + x / div) * 4;
            out[so] += r * s;
            out[so + 1] += g * s;
            out[so + 2] += b * s;
            any = true;
        }
    }
    if any {
        let inv = 1.0 / (div * div) as f32;
        for v in out.iter_mut() {
            *v *= inv;
        }
    }
    (out, sw, sh, any)
}
