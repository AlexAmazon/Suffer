//! Deterministic hash-based noise. Same inputs always give the same output.

pub fn hash_u32(mut x: u32) -> u32 {
    x ^= x >> 16;
    x = x.wrapping_mul(0x7feb_352d);
    x ^= x >> 15;
    x = x.wrapping_mul(0x846c_a68b);
    x ^= x >> 16;
    x
}

/// Uniform value in [0, 1) from three integers.
pub fn rnd(a: u32, b: u32, c: u32) -> f32 {
    let h = hash_u32(
        a.wrapping_mul(0x9E37_79B1)
            ^ hash_u32(b.wrapping_add(0x85EB_CA6B) ^ hash_u32(c.wrapping_add(0xC2B2_AE35))),
    );
    (h >> 8) as f32 / 16_777_216.0
}

#[inline]
fn smooth(f: f32) -> f32 {
    f * f * (3.0 - 2.0 * f)
}

/// Smooth 1-D value noise in [0, 1) along x, for the lane (a, b).
pub fn vnoise(x: f32, a: u32, b: u32) -> f32 {
    let i = x.floor();
    let s = smooth(x - i);
    let i = i as i32 as u32;
    let n0 = rnd(i, a, b);
    let n1 = rnd(i.wrapping_add(1), a, b);
    n0 + (n1 - n0) * s
}

/// Smooth 2-D value noise in [0, 1).
pub fn vnoise2(x: f32, y: f32, seed: u32) -> f32 {
    let xf = x.floor();
    let yf = y.floor();
    let sx = smooth(x - xf);
    let sy = smooth(y - yf);
    let ix = xf as i32 as u32;
    let iy = yf as i32 as u32;
    let a = rnd(ix, iy, seed);
    let b = rnd(ix.wrapping_add(1), iy, seed);
    let c = rnd(ix, iy.wrapping_add(1), seed);
    let d = rnd(ix.wrapping_add(1), iy.wrapping_add(1), seed);
    let top = a + (b - a) * sx;
    let bot = c + (d - c) * sx;
    top + (bot - top) * sy
}

/// Fractal 1-D noise in [-1, 1] (several octaves of smooth noise).
pub fn fbm1(t: f32, octaves: u32, lane: u32, seed: u32) -> f32 {
    let octaves = octaves.clamp(1, 6);
    let mut sum = 0.0f32;
    let mut total = 0.0f32;
    let mut amp = 1.0f32;
    let mut freq = 1.0f32;
    for o in 0..octaves {
        let n = vnoise(t * freq + o as f32 * 13.7, lane, seed.wrapping_add(o.wrapping_mul(977)));
        sum += amp * (n * 2.0 - 1.0);
        total += amp;
        amp *= 0.5;
        freq *= 2.0;
    }
    sum / total
}

/// Fractal 2-D noise in [0, 1).
pub fn fbm2(x: f32, y: f32, octaves: u32, seed: u32) -> f32 {
    let octaves = octaves.clamp(1, 6);
    let mut sum = 0.0f32;
    let mut total = 0.0f32;
    let mut amp = 1.0f32;
    let mut freq = 1.0f32;
    for o in 0..octaves {
        sum += amp
            * vnoise2(
                x * freq + o as f32 * 17.3,
                y * freq - o as f32 * 9.1,
                seed.wrapping_add(o.wrapping_mul(131)),
            );
        total += amp;
        amp *= 0.5;
        freq *= 2.0;
    }
    sum / total
}

/// 2-D fractal noise that morphs over time `t` by cross-fading between lattices.
pub fn fbm2_t(x: f32, y: f32, t: f32, octaves: u32, seed: u32) -> f32 {
    let t0 = t.floor();
    let s = smooth(t - t0);
    let i = t0 as i32 as u32;
    let a = fbm2(x, y, octaves, seed.wrapping_add(i.wrapping_mul(7919)));
    let b = fbm2(x, y, octaves, seed.wrapping_add(i.wrapping_add(1).wrapping_mul(7919)));
    a + (b - a) * s
}

/// Cheap per-pixel hash (about a third of the cost of `rnd`). Use for grain and static.
#[inline(always)]
pub fn hash2(x: u32, y: u32, s: u32) -> u32 {
    let mut h = x.wrapping_mul(0x27d4_eb2d) ^ y.wrapping_mul(0x1656_67b1) ^ s.wrapping_mul(0x9E37_79B1);
    h ^= h >> 15;
    h = h.wrapping_mul(0x85eb_ca6b);
    h ^= h >> 13;
    h = h.wrapping_mul(0xc2b2_ae35);
    h ^ (h >> 16)
}

/// Turn the top 24 bits of a hash into a value in [0, 1).
#[inline(always)]
pub fn unit(h: u32) -> f32 {
    (h >> 8) as f32 * (1.0 / 16_777_216.0)
}
