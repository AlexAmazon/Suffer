//! Shared helpers for the Suffer effect suite (EffectCraft plug-in API v1).
//!
//! Every effect crate calls `export_effect!` once; that macro writes the
//! WebAssembly entry points (`ec_api_version`, `ec_manifest_ptr`, ...) so the
//! effect itself is just a manifest, a `Params` type and a `render` function.

pub mod color;
pub mod glint;
pub mod img;
pub mod lens;
pub mod noise;

pub use std::f32::consts::PI;

/// Read parameter `i` from the host's parameter list, or fall back to `d`.
pub fn pget(v: &[f64], i: usize, d: f64) -> f32 {
    let x = v.get(i).copied().unwrap_or(d);
    if x.is_finite() {
        x as f32
    } else {
        d as f32
    }
}

/// Writes the plug-in exports. Arguments: the manifest `static &str`, the
/// `Params` type (needs `fn from_slice(&[f64]) -> Self`) and the render function
/// `fn(&mut [f32], usize, usize, f64, f32, &Params)` = (pixels, w, h, time, scale, params).
#[macro_export]
macro_rules! export_effect {
    ($manifest:expr, $params:ty, $render:path) => {
        #[no_mangle]
        pub extern "C" fn ec_api_version() -> i32 {
            1
        }

        #[no_mangle]
        pub extern "C" fn ec_manifest_ptr() -> i32 {
            $manifest.as_ptr() as usize as i32
        }

        #[no_mangle]
        pub extern "C" fn ec_manifest_len() -> i32 {
            $manifest.len() as i32
        }

        #[no_mangle]
        pub extern "C" fn ec_alloc(bytes: i32) -> i32 {
            let words = ((bytes.max(0) as usize) + 7) / 8;
            let mut v: ::std::vec::Vec<u64> = ::std::vec![0u64; words.max(1)];
            let ptr = v.as_mut_ptr();
            ::std::mem::forget(v);
            ptr as usize as i32
        }

        #[no_mangle]
        pub unsafe extern "C" fn ec_render(
            pixels: i32,
            width: i32,
            height: i32,
            params: i32,
            nparams: i32,
            time: f64,
            scale: f64,
        ) -> i32 {
            if width <= 0 || height <= 0 {
                return 1;
            }
            let (w, h) = (width as usize, height as usize);
            let px = ::std::slice::from_raw_parts_mut(pixels as usize as *mut f32, w * h * 4);
            let raw: &[f64] = if nparams > 0 {
                ::std::slice::from_raw_parts(params as usize as *const f64, nparams as usize)
            } else {
                &[]
            };
            let p = <$params>::from_slice(raw);
            let scale = if scale.is_finite() && scale > 0.0 { scale as f32 } else { 1.0 };
            $render(px, w, h, time, scale, &p);
            0
        }
    };
}

/// Opaque colour gradient used by the smoke tests in each effect crate.
pub fn test_image(w: usize, h: usize) -> Vec<f32> {
    let mut px = vec![0.0f32; w * h * 4];
    for y in 0..h {
        for x in 0..w {
            let o = (y * w + x) * 4;
            let u = x as f32 / w as f32;
            px[o] = u;
            px[o + 1] = 1.0 - u;
            px[o + 2] = y as f32 / h as f32;
            px[o + 3] = 1.0;
        }
    }
    // a few bright spots so glow / glint style effects have something to do
    for &(sx, sy) in &[(w / 4, h / 4), (w / 2, h / 2), (3 * w / 4, h / 3)] {
        let o = (sy * w + sx) * 4;
        px[o] = 3.0;
        px[o + 1] = 3.0;
        px[o + 2] = 3.0;
    }
    px
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pget_falls_back_for_missing_and_bad_values() {
        assert_eq!(pget(&[], 0, 2.5), 2.5);
        assert_eq!(pget(&[f64::NAN], 0, 1.0), 1.0);
        assert_eq!(pget(&[4.0], 0, 1.0), 4.0);
    }

    #[test]
    fn blur_keeps_a_flat_image_flat() {
        let (w, h) = (16, 12);
        let mut px = vec![0.5f32; w * h * 4];
        img::gauss_blur_xy(&mut px, w, h, 4, 3.0, 3.0);
        assert!(px.iter().all(|v| (v - 0.5).abs() < 1e-4));
    }

    #[test]
    fn noise_is_deterministic_and_in_range() {
        for i in 0..200 {
            let x = i as f32 * 0.37;
            let a = noise::vnoise2(x, x * 0.5, 3);
            assert_eq!(a, noise::vnoise2(x, x * 0.5, 3));
            assert!((0.0..=1.0).contains(&a));
            let f = noise::fbm1(x, 3, 1, 0);
            assert!((-1.0..=1.0).contains(&f));
        }
    }
}
