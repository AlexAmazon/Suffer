//! Suffer TV Damage: an old CRT with reception trouble.
//!
//! One warp pass (screen curvature, vertical roll, horizontal hold errors), then a
//! per-pixel pass for ghosting, interference, static, hum bars, scanlines, the
//! roll seam, vignette and mono. Every control at 0 switches that part off.
//!
//! Speed: the warp is skipped when nothing needs warping, the diagonal interference
//! uses a precomputed sin/cos split (no trig per pixel), and static uses a cheap hash.
use suffer_common::{color, export_effect, img, noise, pget, PI};

static MANIFEST: &str = r#"{
  "api": 1,
  "id": "suffer.tv_damage",
  "name": "Suffer TV Damage",
  "category": "Suffer",
  "params": [
    { "id": "amount",       "name": "Amount",       "type": "slider", "default": 1.0,  "min": 0.0, "max": 1.0 },
    { "id": "static_amt",   "name": "Static",       "type": "slider", "default": 0.25, "min": 0.0, "max": 1.0 },
    { "id": "interference", "name": "Interference", "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "ghosting",     "name": "Ghosting",     "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "h_hold",       "name": "Horizontal Hold", "type": "slider", "default": 0.2, "min": 0.0, "max": 1.0 },
    { "id": "v_roll",       "name": "Vertical Roll","type": "slider", "default": 0.0,  "min": 0.0, "max": 1.0 },
    { "id": "hum_bars",     "name": "Hum Bars",     "type": "slider", "default": 0.3,  "min": 0.0, "max": 1.0 },
    { "id": "scanlines",    "name": "Scanlines",    "type": "slider", "default": 0.4,  "min": 0.0, "max": 1.0 },
    { "id": "vignette",     "name": "Vignette",     "type": "slider", "default": 0.4,  "min": 0.0, "max": 1.0 },
    { "id": "curvature",    "name": "Screen Curvature", "type": "slider", "default": 0.3, "min": 0.0, "max": 1.0 },
    { "id": "mono",         "name": "Black and White", "type": "slider", "default": 0.0, "min": 0.0, "max": 1.0 },
    { "id": "seed",         "name": "Random Seed",  "type": "slider", "default": 0.0,  "min": 0.0, "max": 100.0 }
  ]
}"#;

pub struct Params {
    pub amount: f32,
    pub static_amt: f32,
    pub interference: f32,
    pub ghosting: f32,
    pub h_hold: f32,
    pub v_roll: f32,
    pub hum_bars: f32,
    pub scanlines: f32,
    pub vignette: f32,
    pub curvature: f32,
    pub mono: f32,
    pub seed: u32,
}

impl Params {
    pub fn from_slice(v: &[f64]) -> Self {
        Params {
            amount: pget(v, 0, 1.0).clamp(0.0, 1.0),
            static_amt: pget(v, 1, 0.25).clamp(0.0, 1.0),
            interference: pget(v, 2, 0.3).clamp(0.0, 1.0),
            ghosting: pget(v, 3, 0.3).clamp(0.0, 1.0),
            h_hold: pget(v, 4, 0.2).clamp(0.0, 1.0),
            v_roll: pget(v, 5, 0.0).clamp(0.0, 1.0),
            hum_bars: pget(v, 6, 0.3).clamp(0.0, 1.0),
            scanlines: pget(v, 7, 0.4).clamp(0.0, 1.0),
            vignette: pget(v, 8, 0.4).clamp(0.0, 1.0),
            curvature: pget(v, 9, 0.3).clamp(0.0, 1.0),
            mono: pget(v, 10, 0.0).clamp(0.0, 1.0),
            seed: pget(v, 11, 0.0).max(0.0).round() as u32,
        }
    }
}

pub fn render(px: &mut [f32], w: usize, h: usize, time: f64, scale: f32, p: &Params) {
    if w < 4 || h < 4 || p.amount <= 0.0 || px.len() < w * h * 4 {
        return;
    }
    let t = time as f32;
    let frame = (time * 30.0).floor() as i64 as u32;
    let seed = p.seed;
    let seedf = seed as f32;
    let n = w * h;
    let orig = px[..n * 4].to_vec();
    let wf = w as f32;
    let hf = h as f32;
    let cx = wf * 0.5;
    let cy = hf * 0.5;

    // Vertical roll: the picture slides up and snaps back, leaving a dark seam.
    let voff = p.v_roll * hf * (t * 0.25 + seedf * 0.13).rem_euclid(1.0);

    // Horizontal hold: each line drifts sideways by a smoothly changing amount.
    let mut row_dx = vec![0.0f32; h];
    if p.h_hold > 0.0 {
        for y in 0..h {
            row_dx[y] = p.h_hold * 60.0 * scale * noise::fbm1(y as f32 * 0.012 + t * 1.7, 2, 11, seed);
        }
    }

    // 1. Warp: curvature + roll + hold in one resample (skipped if none are active).
    //    Outside the curved screen stays transparent.
    let curv = p.curvature * 0.25;
    let warp_needed = curv > 0.0 || p.h_hold > 0.0 || voff > 0.0;
    let mut warped: Vec<f32> = Vec::new();
    if warp_needed {
        warped = vec![0.0f32; n * 4];
        for y in 0..h {
            let v = (y as f32 + 0.5 - cy) / cy;
            let vv = v * v;
            let rdx = row_dx[y];
            let wrow = y * w * 4;
            for x in 0..w {
                let u = (x as f32 + 0.5 - cx) / cx;
                let su = u * (1.0 + curv * vv);
                let sv = v * (1.0 + curv * u * u);
                if su.abs() > 1.0 || sv.abs() > 1.0 {
                    continue;
                }
                let sx = cx + su * cx - rdx;
                let mut sy = cy + sv * cy + voff;
                if sy >= hf {
                    sy -= hf;
                } else if sy < 0.0 {
                    sy += hf;
                }
                let c = img::bilerp4(&orig, w, h, sx - 0.5, sy - 0.5, true);
                let o = wrow + x * 4;
                warped[o] = c[0];
                warped[o + 1] = c[1];
                warped[o + 2] = c[2];
                warped[o + 3] = c[3];
            }
        }
    }
    let src: &[f32] = if warp_needed { &warped } else { &orig };

    // 2. Per-pixel look.
    let ghost_dx = (10.0 * scale).round() as i32;
    let seam_row = (hf - voff).rem_euclid(hf);
    let hum_center = (t * 0.08 + seedf * 0.3).rem_euclid(1.0);
    let intf_gain = p.interference * 0.15 * (0.6 + 0.4 * (t * 0.7).sin());
    let stat_gain = p.static_amt * 0.6;
    let inv_cx = 1.0 / cx;
    let full_mix = p.amount >= 0.999;

    // sin/cos of the horizontal part of the interference pattern, once per column.
    let mut sinx = vec![0.0f32; w];
    let mut cosx = vec![0.0f32; w];
    for x in 0..w {
        let (s, c) = (2.0 * PI * (x as f32 / wf * 3.0)).sin_cos();
        sinx[x] = s;
        cosx[x] = c;
    }

    for y in 0..h {
        let yn = y as f32 / hf;
        let v = (y as f32 + 0.5 - cy) / cy;

        // Row-constant factors: hum bar, scanline, roll seam, interference phase.
        let d = (yn - hum_center + 0.5).rem_euclid(1.0) - 0.5;
        let bump = (-(d / 0.12) * (d / 0.12)).exp();
        let hum = 1.0 - p.hum_bars * 0.35 * bump;
        let scan = 1.0 - p.scanlines * 0.3 * (0.5 + 0.5 * (PI * y as f32 / scale).cos());
        let dy_seam = (y as f32 - seam_row).abs();
        let seam_dist = dy_seam.min(hf - dy_seam) / (hf * 0.03);
        let seam = if voff > 0.5 { 1.0 - 0.8 * (1.0 - seam_dist).max(0.0) } else { 1.0 };
        let row_gain = hum * scan * seam;
        let (sb, cb) = (2.0 * PI * (yn * 14.0 - t * 1.3)).sin_cos();

        for x in 0..w {
            let o = (y * w + x) * 4;
            let a = src[o + 3];
            let u = (x as f32 + 0.5 - cx) * inv_cx;
            let mut r = src[o];
            let mut g = src[o + 1];
            let mut b = src[o + 2];

            // Ghosting: a faint copy pushed to the right.
            if p.ghosting > 0.0 {
                let xg = (x as i32 - ghost_dx).clamp(0, w as i32 - 1) as usize;
                let og = (y * w + xg) * 4;
                r += p.ghosting * 0.3 * src[og];
                g += p.ghosting * 0.3 * src[og + 1];
                b += p.ghosting * 0.3 * src[og + 2];
            }

            // Interference (diagonal bands) and static, added equally to R, G and B.
            let intf = intf_gain * (sinx[x] * cb + cosx[x] * sb);
            let stat = (noise::unit(noise::hash2(x as u32, y as u32, frame ^ seed)) - 0.5) * stat_gain;
            let add = (intf + stat) * a;

            let vig = (1.0 - p.vignette * 0.7 * (u * u + v * v)).max(0.0);
            let m = row_gain * vig;
            r = (r + add) * m;
            g = (g + add) * m;
            b = (b + add) * m;

            if p.mono > 0.0 {
                let l = color::luma(r, g, b);
                r += (l - r) * p.mono;
                g += (l - g) * p.mono;
                b += (l - b) * p.mono;
            }

            let eff = [r.max(0.0), g.max(0.0), b.max(0.0), a];
            if full_mix {
                for c in 0..4 {
                    px[o + c] = if eff[c].is_finite() { eff[c] } else { orig[o + c] };
                }
            } else {
                for c in 0..4 {
                    let val = orig[o + c] + (eff[c] - orig[o + c]) * p.amount;
                    px[o + c] = if val.is_finite() { val } else { orig[o + c] };
                }
            }
        }
    }
}

export_effect!(MANIFEST, Params, render);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn smoke() {
        let (w, h) = (64, 48);
        let mut px = suffer_common::test_image(w, h);
        render(&mut px, w, h, 1.0, 1.0, &Params::from_slice(&[]));
        assert!(px.iter().all(|v| v.is_finite()));
    }
    #[test]
    fn everything_on_stays_finite() {
        let (w, h) = (64, 48);
        let mut px = suffer_common::test_image(w, h);
        let all = [1.0; 12];
        render(&mut px, w, h, 2.7, 1.0, &Params::from_slice(&all));
        assert!(px.iter().all(|v| v.is_finite()));
    }
    #[test]
    fn no_warp_path_runs() {
        let (w, h) = (64, 48);
        let mut px = suffer_common::test_image(w, h);
        let p = Params::from_slice(&[1.0, 0.2, 0.2, 0.2, 0.0, 0.0, 0.2, 0.2, 0.2, 0.0]);
        render(&mut px, w, h, 1.0, 1.0, &p);
        assert!(px.iter().all(|v| v.is_finite()));
    }
}
